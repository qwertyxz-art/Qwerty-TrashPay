#!/usr/bin/env python3
"""Creates the android/ folder of one app and applies TrashPay's small changes.

Why: the Gradle files of an Android project must match the Flutter version
that builds it. Instead of keeping hand-written Gradle files in the repository
(which go out of date), this script asks the installed Flutter for its own,
current template, then changes only what the apps need:

  * app name (label), INTERNET permission (and CAMERA for the student app)
  * Skia renderer (Impeller is switched off: it can crash some phones at launch)
  * launcher icon and navy launch background

Usage (from the repository root, Flutter on the PATH):
    python3 tools/setup_android.py trash_school
    python3 tools/setup_android.py trash_school_admin
"""
import os
import re
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

APPS = {
    "trash_school": {"label": "TrashPay Schools", "camera": True},
    "trash_school_admin": {"label": "TrashPay Admin", "camera": False},
}

COLORS_XML = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="navy_midnight">#0A0F2C</color>
</resources>
"""

LAUNCH_BACKGROUND_XML = """<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@color/navy_midnight" />
</layer-list>
"""


def fail(message):
    print("ERROR: " + message, file=sys.stderr)
    sys.exit(1)


def read(path):
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def insert_before_line_of(text, marker, addition, from_end=False):
    """Inserts `addition` on its own lines right before the line holding `marker`."""
    index = text.rfind(marker) if from_end else text.find(marker)
    if index < 0:
        fail("could not find %r in the generated AndroidManifest.xml" % marker)
    line_start = text.rfind("\n", 0, index) + 1
    return text[:line_start] + addition + text[line_start:]


def patch_manifest(android_dir, label, camera):
    path = os.path.join(android_dir, "app", "src", "main", "AndroidManifest.xml")
    if not os.path.isfile(path):
        fail("generated manifest not found: " + path)
    text = read(path)

    text, count = re.subn(r'android:label="[^"]*"', 'android:label="%s"' % label, text, count=1)
    if count != 1:
        fail("no android:label in the generated AndroidManifest.xml")

    permissions = []
    if "android.permission.INTERNET" not in text:
        permissions.append('<uses-permission android:name="android.permission.INTERNET" />')
    if camera:
        if "android.permission.CAMERA" not in text:
            permissions.append('<uses-permission android:name="android.permission.CAMERA" />')
        if "android.hardware.camera" not in text:
            permissions.append(
                '<uses-feature android:name="android.hardware.camera" android:required="false" />'
            )
    if permissions:
        addition = "".join("    %s\n" % line for line in permissions)
        text = insert_before_line_of(text, "<application", addition)

    if "EnableImpeller" not in text:
        meta = (
            "        <!-- Stable Skia renderer: Impeller can crash on launch on some phones. -->\n"
            "        <meta-data\n"
            '            android:name="io.flutter.embedding.android.EnableImpeller"\n'
            '            android:value="false" />\n'
        )
        text = insert_before_line_of(text, "</application>", meta, from_end=True)

    # The two things every build of these apps must have.
    if "${applicationName}" not in text:
        fail('AndroidManifest.xml has no android:name="${applicationName}"')
    if not re.search(r'android:name="flutterEmbedding"\s+android:value="2"', text):
        fail("AndroidManifest.xml has no flutterEmbedding = 2")

    write(path, text)


def patch_resources(app, android_dir):
    res = os.path.join(android_dir, "app", "src", "main", "res")

    # Launcher icon: our PNGs win over whatever the template ships.
    for name in os.listdir(res) if os.path.isdir(res) else []:
        if name.startswith("mipmap-anydpi"):
            shutil.rmtree(os.path.join(res, name))
    icons = os.path.join(ROOT, "tools", "icons", app)
    if os.path.isdir(icons):
        shutil.copytree(icons, res, dirs_exist_ok=True)

    # Navy launch background instead of white (only touches files that exist).
    write(os.path.join(res, "values", "trashpay_colors.xml"), COLORS_XML)
    for folder in ("drawable", "drawable-v21"):
        path = os.path.join(res, folder, "launch_background.xml")
        if os.path.isfile(path):
            write(path, LAUNCH_BACKGROUND_XML)
    for folder in ("values", "values-night"):
        path = os.path.join(res, folder, "styles.xml")
        if os.path.isfile(path):
            text = read(path)
            patched = text.replace("?android:colorBackground", "@color/navy_midnight")
            if patched != text:
                write(path, patched)


def patch_android(app, android_dir):
    config = APPS[app]
    patch_manifest(android_dir, config["label"], config["camera"])
    patch_resources(app, android_dir)


def snapshot(app_dir):
    """Remembers pubspec.yaml and lib/ so `flutter create` can never alter them."""
    files = {}
    pubspec = os.path.join(app_dir, "pubspec.yaml")
    with open(pubspec, "rb") as handle:
        files[pubspec] = handle.read()
    for folder, _dirs, names in os.walk(os.path.join(app_dir, "lib")):
        for name in names:
            path = os.path.join(folder, name)
            with open(path, "rb") as handle:
                files[path] = handle.read()
    return files


def restore(files):
    for path, content in files.items():
        current = None
        if os.path.isfile(path):
            with open(path, "rb") as handle:
                current = handle.read()
        if current != content:
            print("restoring " + os.path.relpath(path, ROOT))
            with open(path, "wb") as handle:
                handle.write(content)


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in APPS:
        fail("usage: python3 tools/setup_android.py <%s>" % "|".join(APPS))
    app = sys.argv[1]
    app_dir = os.path.join(ROOT, app)
    android_dir = os.path.join(app_dir, "android")

    saved = snapshot(app_dir)
    if os.path.isdir(android_dir):
        shutil.rmtree(android_dir)

    flutter = shutil.which("flutter") or "flutter"
    subprocess.run(
        [
            flutter,
            "create",
            ".",
            "--platforms=android",
            "--org",
            "com.trashpay",
            "--project-name",
            app,
        ],
        cwd=app_dir,
        check=True,
    )
    restore(saved)

    patch_android(app, android_dir)
    print("android/ for %s is ready." % app)


if __name__ == "__main__":
    main()
