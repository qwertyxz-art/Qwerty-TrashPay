# TrashPay Admin

Sign in as the principal, create QR tickets after weighing, review pending weighings, open a student's QR code, read the full history, and use "Seed Demo Data" for presentations.

Data lives in Supabase or Firebase. Setup steps are in the README at the root of the zip; set the backend and its keys in `lib/cloud_config.dart`.

```
# from the repository root, once (creates android/ with your Flutter's template)
python3 tools/setup_android.py trash_school_admin

cd trash_school_admin
flutter pub get
flutter run
flutter build apk --release --no-shrink
```
