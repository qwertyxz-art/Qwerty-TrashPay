import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';

import 'format.dart';
import 'shared_store.dart';
import 'theme.dart';
import 'widgets/widgets.dart';

/// Admin: pick the student, type the weight read from the scale, and show the
/// one-time QR ticket the student scans to receive the balance.
class NewWeighingSheet extends StatefulWidget {
  const NewWeighingSheet({super.key, required this.students});

  final List<AppUser> students;

  @override
  State<NewWeighingSheet> createState() => _NewWeighingSheetState();
}

class _NewWeighingSheetState extends State<NewWeighingSheet> {
  final TextEditingController _kg = TextEditingController();

  AppUser? _student;
  Ticket? _ticket;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _kg.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    if (_busy) return;
    FocusScope.of(context).unfocus();
    final student = _student;
    final kg = double.tryParse(_kg.text.trim().replaceAll(',', '.'));
    if (student == null) {
      setState(() => _error = 'Choose the student first.');
      return;
    }
    if (kg == null || kg <= 0 || kg > 100) {
      setState(() => _error = 'Enter the weight from the scale (0.1 to 100 kg).');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final ticket = await SharedStore.createTicket(userId: student.id, kg: kg);
      if (!mounted) return;
      setState(() {
        _ticket = ticket;
        _busy = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = '$error';
      });
    }
  }

  void _another() {
    setState(() {
      _ticket = null;
      _kg.clear();
      _error = null;
    });
  }

  Widget _form() {
    if (widget.students.isEmpty) {
      return const Text(
        'No students yet. Students appear here after they register '
        '(or tap Seed Demo Data).',
        style: TextStyle(color: AppColors.textMuted),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        DropdownButtonFormField<AppUser>(
          value: _student,
          isExpanded: true,
          dropdownColor: AppColors.surface,
          decoration: appInputDecoration(
            label: 'Student',
            icon: Icons.person_outline,
          ),
          items: [
            for (final user in widget.students)
              DropdownMenuItem<AppUser>(
                value: user,
                child: Text(user.name, overflow: TextOverflow.ellipsis),
              ),
          ],
          onChanged: (user) => setState(() => _student = user),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _kg,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
          onSubmitted: (_) => _create(),
          decoration: appInputDecoration(
            label: 'Weight from the scale (kg)',
            hint: 'e.g. 5.0',
            icon: Icons.scale_outlined,
          ),
        ),
        if (_error != null) ...[
          const SizedBox(height: 12),
          Text(_error!, style: const TextStyle(color: AppColors.danger)),
        ],
        const SizedBox(height: 18),
        AnimatedButton(
          label: 'Create QR ticket',
          icon: Icons.qr_code_2,
          loading: _busy,
          onPressed: _create,
        ),
      ],
    );
  }

  Widget _ticketView(Ticket ticket) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Center(
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            child: QrImageView(
              data: ticket.payload,
              version: QrVersions.auto,
              size: 220,
              padding: EdgeInsets.zero,
              backgroundColor: Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 14),
        Text(
          _student?.name ?? '',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 2),
        Text(
          '${formatKg(ticket.kg)} = ${formatRupiah(ticket.amount)}',
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: AppColors.accent,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'Code: ${ticket.code}',
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Works once, for this student only, until ${formatDateTime(ticket.expiresAt)}.',
          textAlign: TextAlign.center,
          style: const TextStyle(color: AppColors.textMuted, fontSize: 13),
        ),
        const SizedBox(height: 16),
        AnimatedButton(
          label: 'Copy code',
          icon: Icons.copy,
          style: AppButtonStyle.outlined,
          onPressed: () async {
            await Clipboard.setData(ClipboardData(text: ticket.code));
            if (!mounted) return;
            showAppSnack(context, 'Code copied.');
          },
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: AnimatedButton(
                label: 'Another',
                style: AppButtonStyle.tonal,
                onPressed: _another,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: AnimatedButton(
                label: 'Done',
                onPressed: () => Navigator.of(context).pop(),
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final ticket = _ticket;
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        16,
        20,
        20 + MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 42,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.textMuted.withAlpha(80),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              ticket == null ? 'New weighing' : 'Show this to the student',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            if (ticket == null)
              const Text(
                'Weigh the waste on the scale, enter the weight, and the '
                'student scans the QR to receive the balance.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textMuted),
              ),
            const SizedBox(height: 18),
            ticket == null ? _form() : _ticketView(ticket),
          ],
        ),
      ),
    );
  }
}
