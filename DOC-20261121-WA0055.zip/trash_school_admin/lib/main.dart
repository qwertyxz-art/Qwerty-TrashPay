import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import 'crash_guard.dart';
import 'format.dart';
import 'shared_store.dart';
import 'theme.dart';
import 'update_checker.dart';
import 'weighing_sheet.dart';
import 'widgets/widgets.dart';

void main() {
  runAppGuarded(() => const TrashSchoolAdminApp());
}

class TrashSchoolAdminApp extends StatelessWidget {
  const TrashSchoolAdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TrashPay Admin',
      debugShowCheckedModeBanner: false,
      theme: buildNavyTheme(),
      home: const AdminGate(),
    );
  }
}

class AdminGate extends StatefulWidget {
  const AdminGate({super.key});

  @override
  State<AdminGate> createState() => _AdminGateState();
}

class _AdminGateState extends State<AdminGate> {
  bool _booting = true;
  bool _loggedIn = false;

  @override
  void initState() {
    super.initState();
    _restore();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        UpdateChecker.promptIfAvailable(
          context,
          apkName: 'trash_school_admin.apk',
        );
      }
    });
  }

  Future<void> _restore() async {
    var ok = false;
    try {
      final user = await SharedStore.restoreSession();
      ok = user != null && user.isAdmin;
      if (user != null && !user.isAdmin) await SharedStore.signOut();
    } catch (_) {
      ok = false;
    }
    if (!mounted) return;
    setState(() {
      _loggedIn = ok;
      _booting = false;
    });
  }

  Future<void> _logout() async {
    try {
      await SharedStore.signOut();
    } catch (_) {
      // Ignore: the admin is leaving the screen anyway.
    }
    if (!mounted) return;
    setState(() => _loggedIn = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_booting) {
      return const Scaffold(
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: SkeletonList(count: 4),
          ),
        ),
      );
    }
    if (!_loggedIn) {
      return AdminLoginScreen(onLoggedIn: () => setState(() => _loggedIn = true));
    }
    return AdminShell(onLogout: _logout);
  }
}

// ---------------------------------------------------------------------------
// Login
// ---------------------------------------------------------------------------

class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key, required this.onLoggedIn});

  final VoidCallback onLoggedIn;

  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final TextEditingController _username = TextEditingController();
  final TextEditingController _password = TextEditingController();
  bool _obscure = true;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await SharedStore.signInAdmin(
        username: _username.text,
        password: _password.text,
      );
      if (!mounted) return;
      widget.onLoggedIn();
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = '$error';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(
                    child: Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        color: AppColors.accent.withAlpha(32),
                        shape: BoxShape.circle,
                        border: Border.all(color: AppColors.accent.withAlpha(120)),
                      ),
                      child: const Icon(
                        Icons.admin_panel_settings_outlined,
                        size: 40,
                        color: AppColors.accent,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'TrashPay Admin',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Review student weighings and manage the school waste bank.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.textMuted, fontSize: 15),
                  ),
                  const SizedBox(height: 32),
                  TextField(
                    controller: _username,
                    textInputAction: TextInputAction.next,
                    autocorrect: false,
                    enableSuggestions: false,
                    decoration: appInputDecoration(
                      label: 'Username',
                      icon: Icons.person_outline,
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _password,
                    obscureText: _obscure,
                    autocorrect: false,
                    enableSuggestions: false,
                    textInputAction: TextInputAction.done,
                    onSubmitted: (_) => _submit(),
                    decoration: appInputDecoration(
                      label: 'Password',
                      icon: Icons.lock_outline,
                      suffix: PressableIconButton(
                        icon: _obscure
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        tooltip: _obscure ? 'Show password' : 'Hide password',
                        color: AppColors.textMuted,
                        onPressed: () => setState(() => _obscure = !_obscure),
                      ),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.danger.withAlpha(28),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.danger.withAlpha(120)),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.error_outline,
                            color: AppColors.danger,
                            size: 20,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              _error!,
                              style: const TextStyle(color: AppColors.danger),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 24),
                  AnimatedButton(
                    label: 'Sign in',
                    icon: Icons.login,
                    loading: _busy,
                    onPressed: _submit,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Shell: app bar, bottom navigation and shared data
// ---------------------------------------------------------------------------

class AdminShell extends StatefulWidget {
  const AdminShell({super.key, required this.onLogout});

  final VoidCallback onLogout;

  @override
  State<AdminShell> createState() => _AdminShellState();
}

class _AdminShellState extends State<AdminShell> {
  List<AppUser> _users = const <AppUser>[];
  List<TxRecord> _pending = const <TxRecord>[];
  List<TxRecord> _history = const <TxRecord>[];
  StoreStats? _stats;
  bool _loading = true;
  bool _seeding = false;
  int _tab = 0;
  final Set<String> _busyIds = <String>{};

  @override
  void initState() {
    super.initState();
    _load(first: true);
  }

  Future<void> _load({bool first = false}) async {
    if (first) {
      // Short pause so the shimmer skeleton is visible on first open.
      await Future<void>.delayed(const Duration(milliseconds: 500));
    }
    try {
      final users = await SharedStore.getUsers();
      final pending = await SharedStore.getPendingWeighings();
      final stats = await SharedStore.getStats();
      final history = await SharedStore.getTransactions();
      if (!mounted) return;
      setState(() {
        _users = users;
        _pending = pending;
        _history = history;
        _stats = stats;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      showAppSnack(context, 'Could not load data: $error', error: true);
    }
  }

  String _nameOf(String userId) {
    for (final user in _users) {
      if (user.id == userId) return user.name;
    }
    return 'Unknown student';
  }

  Future<void> _seed() async {
    if (_seeding) return;
    setState(() => _seeding = true);
    try {
      await SharedStore.seedDemoData();
      await _load();
      if (!mounted) return;
      showAppSnack(context, 'Demo data added: 2 students and 2 pending weighings.');
    } catch (error) {
      if (!mounted) return;
      showAppSnack(context, 'Could not add demo data: $error', error: true);
    } finally {
      if (mounted) setState(() => _seeding = false);
    }
  }

  Future<void> _review(TxRecord tx, {required bool approve}) async {
    if (_busyIds.contains(tx.id)) return;
    setState(() => _busyIds.add(tx.id));
    final name = _nameOf(tx.userId);
    try {
      if (approve) {
        await SharedStore.approveWeighing(tx.id);
      } else {
        await SharedStore.rejectWeighing(tx.id);
      }
      await _load();
      if (!mounted) return;
      showAppSnack(
        context,
        approve
            ? 'Approved ${formatKg(tx.kg)} for $name. ${formatRupiah(tx.amount)} added to their balance.'
            : 'Rejected ${formatKg(tx.kg)} from $name.',
      );
    } catch (error) {
      await _load();
      if (!mounted) return;
      showAppSnack(context, '$error', error: true);
    } finally {
      if (mounted) setState(() => _busyIds.remove(tx.id));
    }
  }

  void _showQr(AppUser user) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _QrSheet(user: user),
    );
  }

  void _newWeighing() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => NewWeighingSheet(students: _users),
    );
  }

  Widget _body() {
    final stats = _stats;
    if (_loading || stats == null) return const _AdminSkeleton();

    switch (_tab) {
      case 0:
        return _DashboardTab(
          stats: stats,
          pendingCount: _pending.length,
          onReview: () => setState(() => _tab = 1),
          onNewWeighing: _newWeighing,
        );
      case 1:
        final byId = <String, AppUser>{for (final u in _users) u.id: u};
        return _PendingTab(
          items: _pending,
          usersById: byId,
          busyIds: _busyIds,
          onApprove: (tx) => _review(tx, approve: true),
          onReject: (tx) => _review(tx, approve: false),
        );
      case 2:
        return _StudentsTab(users: _users, onOpen: _showQr);
      default:
        return _HistoryTab(
          items: _history,
          usersById: <String, AppUser>{for (final u in _users) u.id: u},
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
        actions: [
          Center(
            child: AnimatedButton(
              label: 'Seed Demo Data',
              icon: Icons.auto_awesome,
              expand: false,
              dense: true,
              loading: _seeding,
              onPressed: _loading ? null : _seed,
            ),
          ),
          const SizedBox(width: 4),
          PressableIconButton(
            icon: Icons.refresh,
            tooltip: 'Refresh',
            onPressed: _loading
                ? null
                : () {
                    setState(() => _loading = true);
                    _load();
                  },
          ),
          PressableIconButton(
            icon: Icons.logout,
            tooltip: 'Log out',
            onPressed: widget.onLogout,
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(bottom: false, child: _body()),
      bottomNavigationBar: _BottomNav(
        index: _tab,
        pendingCount: _pending.length,
        onChanged: (index) => setState(() => _tab = index),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Bottom navigation (custom, so every tap uses the press animation)
// ---------------------------------------------------------------------------

class _BottomNav extends StatelessWidget {
  const _BottomNav({
    required this.index,
    required this.pendingCount,
    required this.onChanged,
  });

  final int index;
  final int pendingCount;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
          child: Row(
            children: [
              Expanded(
                child: _NavItem(
                  icon: Icons.dashboard_outlined,
                  activeIcon: Icons.dashboard,
                  label: 'Dashboard',
                  selected: index == 0,
                  onTap: () => onChanged(0),
                ),
              ),
              Expanded(
                child: _NavItem(
                  icon: Icons.pending_actions_outlined,
                  activeIcon: Icons.pending_actions,
                  label: 'Pending',
                  badge: pendingCount,
                  selected: index == 1,
                  onTap: () => onChanged(1),
                ),
              ),
              Expanded(
                child: _NavItem(
                  icon: Icons.groups_outlined,
                  activeIcon: Icons.groups,
                  label: 'Students',
                  selected: index == 2,
                  onTap: () => onChanged(2),
                ),
              ),
              Expanded(
                child: _NavItem(
                  icon: Icons.history,
                  activeIcon: Icons.history,
                  label: 'History',
                  selected: index == 3,
                  onTap: () => onChanged(3),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.selected,
    required this.onTap,
    this.badge = 0,
  });

  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final int badge;

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.accent : AppColors.textMuted;
    return Semantics(
      button: true,
      selected: selected,
      label: label,
      child: PressableScale(
        onPressed: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: selected ? AppColors.accent.withAlpha(30) : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Icon(selected ? activeIcon : icon, color: color, size: 24),
                  if (badge > 0)
                    Positioned(
                      right: -10,
                      top: -6,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                        decoration: BoxDecoration(
                          color: AppColors.danger,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '$badge',
                          style: const TextStyle(
                            color: AppColors.background,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: color,
                  fontSize: 12,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------

class _DashboardTab extends StatelessWidget {
  const _DashboardTab({
    required this.stats,
    required this.pendingCount,
    required this.onReview,
    required this.onNewWeighing,
  });

  final StoreStats stats;
  final int pendingCount;
  final VoidCallback onReview;
  final VoidCallback onNewWeighing;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      children: [
        const Text(
          'Overview',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 4),
        const Text(
          'Totals across all students',
          style: TextStyle(color: AppColors.textMuted),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _StatCard(
                icon: Icons.groups_outlined,
                label: 'Students',
                value: '${stats.students}',
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _StatCard(
                icon: Icons.scale_outlined,
                label: 'Total kg',
                value: formatKg(stats.totalKg),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        _StatCard(
          icon: Icons.account_balance_wallet_outlined,
          label: 'Total Balance',
          value: formatRupiah(stats.totalBalance),
          highlight: true,
        ),
        const SizedBox(height: 12),
        AnimatedButton(
          label: 'New weighing (QR ticket)',
          icon: Icons.qr_code_2,
          onPressed: onNewWeighing,
        ),
        const SizedBox(height: 12),
        AppCard(
          child: Row(
            children: [
              const Icon(Icons.pending_actions_outlined, color: AppColors.warning),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Pending weighings',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      pendingCount == 0
                          ? 'Nothing waiting'
                          : '$pendingCount waiting, ${formatKg(stats.pendingKg)} in total',
                      style: const TextStyle(color: AppColors.textMuted, fontSize: 13),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              AnimatedButton(
                label: 'Review',
                expand: false,
                dense: true,
                onPressed: pendingCount == 0 ? null : onReview,
              ),
            ],
          ),
        ),
        if (stats.students == 0) ...[
          const SizedBox(height: 16),
          const AppCard(
            child: Text(
              'No data yet. Tap Seed Demo Data at the top to add two students and two pending weighings.',
              style: TextStyle(color: AppColors.textMuted, fontSize: 14),
            ),
          ),
        ],
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
    this.highlight = false,
  });

  final IconData icon;
  final String label;
  final String value;
  final bool highlight;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      color: highlight ? AppColors.surfaceHigh : AppColors.surface,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 20, color: AppColors.accent),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: AppColors.textMuted, fontSize: 13),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              value,
              style: TextStyle(
                fontSize: highlight ? 32 : 26,
                fontWeight: FontWeight.w800,
                color: highlight ? AppColors.accent : AppColors.text,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Pending weighings
// ---------------------------------------------------------------------------

class _PendingTab extends StatelessWidget {
  const _PendingTab({
    required this.items,
    required this.usersById,
    required this.busyIds,
    required this.onApprove,
    required this.onReject,
  });

  final List<TxRecord> items;
  final Map<String, AppUser> usersById;
  final Set<String> busyIds;
  final ValueChanged<TxRecord> onApprove;
  final ValueChanged<TxRecord> onReject;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return const _EmptyState(
        icon: Icons.task_alt,
        title: 'Nothing to review',
        message:
            'New weighings from students will show up here. Use Seed Demo Data to add samples.',
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      itemCount: items.length + 1,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        if (index == 0) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Pending weighings',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 4),
              Text(
                'Approve to add the amount to the student balance',
                style: const TextStyle(color: AppColors.textMuted),
              ),
            ],
          );
        }
        final tx = items[index - 1];
        return _PendingCard(
          tx: tx,
          user: usersById[tx.userId],
          busy: busyIds.contains(tx.id),
          onApprove: () => onApprove(tx),
          onReject: () => onReject(tx),
        );
      },
    );
  }
}

class _PendingCard extends StatelessWidget {
  const _PendingCard({
    required this.tx,
    required this.user,
    required this.busy,
    required this.onApprove,
    required this.onReject,
  });

  final TxRecord tx;
  final AppUser? user;
  final bool busy;
  final VoidCallback onApprove;
  final VoidCallback onReject;

  @override
  Widget build(BuildContext context) {
    final name = user?.name ?? 'Unknown student';
    return AppCard(
      child: Column(
        children: [
          Row(
            children: [
              _Avatar(name: name),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      formatDateTime(tx.createdAt),
                      style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    formatKg(tx.kg),
                    style: const TextStyle(
                      color: AppColors.accent,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    formatRupiah(tx.amount),
                    style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: AnimatedButton(
                  label: 'Reject',
                  icon: Icons.close,
                  style: AppButtonStyle.danger,
                  onPressed: busy ? null : onReject,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: AnimatedButton(
                  label: 'Approve',
                  icon: Icons.check,
                  loading: busy,
                  onPressed: onApprove,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Students
// ---------------------------------------------------------------------------

class _StudentsTab extends StatelessWidget {
  const _StudentsTab({required this.users, required this.onOpen});

  final List<AppUser> users;
  final ValueChanged<AppUser> onOpen;

  @override
  Widget build(BuildContext context) {
    if (users.isEmpty) {
      return const _EmptyState(
        icon: Icons.groups_outlined,
        title: 'No students yet',
        message:
            'Students appear here after they sign in on the student app. Use Seed Demo Data to add two samples.',
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      itemCount: users.length + 1,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        if (index == 0) {
          return const Padding(
            padding: EdgeInsets.only(bottom: 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Students',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
                ),
                SizedBox(height: 4),
                Text(
                  'Tap a student to show their QR code',
                  style: TextStyle(color: AppColors.textMuted),
                ),
              ],
            ),
          );
        }
        final user = users[index - 1];
        return PressableScale(
          onPressed: () => onOpen(user),
          child: AppCard(
            padding: const EdgeInsets.all(14),
            radius: 18,
            child: Row(
              children: [
                _Avatar(name: user.name),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        user.ewallet,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: AppColors.textMuted, fontSize: 13),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      formatRupiah(user.balance),
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      formatKg(user.totalKg),
                      style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                    ),
                  ],
                ),
                const SizedBox(width: 10),
                const Icon(Icons.qr_code_2, color: AppColors.accent),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _QrSheet extends StatelessWidget {
  const _QrSheet({required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SheetHandle(),
            const SizedBox(height: 12),
            Text(
              user.name,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            Text(
              '${user.phone}, ${user.ewallet}',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textMuted),
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
              ),
              child: QrImageView(
                data: user.qrPayload,
                version: QrVersions.auto,
                size: 240,
                padding: EdgeInsets.zero,
                backgroundColor: Colors.white,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              'Balance ${formatRupiah(user.balance)}, total ${formatKg(user.totalKg)}',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 20),
            Builder(
              builder: (sheetContext) {
                return AnimatedButton(
                  label: 'Close',
                  style: AppButtonStyle.outlined,
                  onPressed: () => Navigator.of(sheetContext).pop(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Shared small widgets
// ---------------------------------------------------------------------------

class _Avatar extends StatelessWidget {
  const _Avatar({required this.name});

  final String name;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 46,
      height: 46,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: AppColors.accent.withAlpha(30),
        shape: BoxShape.circle,
      ),
      child: Text(
        initialsOf(name),
        style: const TextStyle(
          color: AppColors.accent,
          fontWeight: FontWeight.w800,
          fontSize: 15,
        ),
      ),
    );
  }
}

class _HistoryTab extends StatelessWidget {
  const _HistoryTab({required this.items, required this.usersById});

  final List<TxRecord> items;
  final Map<String, AppUser> usersById;

  Color _statusColor(TxRecord tx) {
    switch (tx.status) {
      case TxStatus.approved:
        return AppColors.success;
      case TxStatus.rejected:
        return AppColors.danger;
      case TxStatus.pending:
        return AppColors.warning;
      default:
        return AppColors.accent;
    }
  }

  String _statusLabel(TxRecord tx) {
    if (tx.isWithdraw) return 'Paid out';
    switch (tx.status) {
      case TxStatus.approved:
        return 'Approved';
      case TxStatus.rejected:
        return 'Rejected';
      default:
        return 'Pending';
    }
  }

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return const _EmptyState(
        icon: Icons.receipt_long_outlined,
        title: 'No history yet',
        message:
            'Every weighing and payout from your students will be listed here.',
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      itemCount: items.length + 1,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        if (index == 0) {
          return const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'History',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
              ),
              SizedBox(height: 4),
              Text(
                'Every weighing and payout from all students',
                style: TextStyle(color: AppColors.textMuted),
              ),
            ],
          );
        }
        final tx = items[index - 1];
        final name = usersById[tx.userId]?.name ?? 'Unknown student';
        final color = _statusColor(tx);
        final amountText =
            '${tx.isWithdraw ? '-' : '+'}${formatRupiah(tx.amount)}';
        return AppCard(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: color.withAlpha(32),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(
                  tx.isWithdraw ? Icons.payments_outlined : Icons.recycling,
                  color: color,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      tx.isWithdraw
                          ? tx.note
                          : '${formatKg(tx.kg)} · ${formatDateTime(tx.createdAt)}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 12,
                      ),
                    ),
                    if (tx.isWithdraw)
                      Text(
                        formatDateTime(tx.createdAt),
                        style: const TextStyle(
                          color: AppColors.textMuted,
                          fontSize: 12,
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    amountText,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: tx.status == TxStatus.rejected
                          ? AppColors.textMuted
                          : AppColors.text,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _statusLabel(tx),
                    style: TextStyle(
                      color: color,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({
    required this.icon,
    required this.title,
    required this.message,
  });

  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 52, color: AppColors.textMuted),
            const SizedBox(height: 16),
            Text(
              title,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textMuted, fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }
}

class _AdminSkeleton extends StatelessWidget {
  const _AdminSkeleton();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.fromLTRB(20, 16, 20, 20),
      child: Shimmer(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: SkeletonBox(width: 140, height: 24, radius: 8),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: SkeletonBox(height: 110, radius: 20)),
                SizedBox(width: 12),
                Expanded(child: SkeletonBox(height: 110, radius: 20)),
              ],
            ),
            SizedBox(height: 12),
            SkeletonBox(height: 120, radius: 20),
            SizedBox(height: 12),
            SkeletonBox(height: 84, radius: 20),
          ],
        ),
      ),
    );
  }
}
