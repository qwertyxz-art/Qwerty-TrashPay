/// Thrown for expected, user-facing problems (bad input, wrong password...).
class StoreException implements Exception {
  StoreException(this.message);

  final String message;

  @override
  String toString() => message;
}

class TxType {
  TxType._();

  static const String deposit = 'deposit';
  static const String withdraw = 'withdraw';
}

class TxStatus {
  TxStatus._();

  static const String pending = 'pending';
  static const String approved = 'approved';
  static const String rejected = 'rejected';
  static const String completed = 'completed';
}

class AppUser {
  const AppUser({
    required this.id,
    required this.name,
    required this.phone,
    required this.ewallet,
    required this.balance,
    required this.totalKg,
    required this.createdAt,
    this.role = 'student',
  });

  final String id;
  final String name;
  final String phone;
  final String ewallet;
  final double balance;
  final double totalKg;
  final DateTime createdAt;
  final String role;

  bool get isAdmin => role == 'admin';

  /// Text encoded into the student's QR code.
  String get qrPayload => 'trashpay://student/$id';

  factory AppUser.fromJson(Map<String, dynamic> json) {
    return AppUser(
      id: json['id'] as String,
      name: (json['name'] as String?) ?? '',
      phone: (json['phone'] as String?) ?? '',
      ewallet: (json['ewallet'] as String?) ?? '',
      balance: (json['balance'] as num?)?.toDouble() ?? 0,
      totalKg: (json['total_kg'] as num?)?.toDouble() ?? 0,
      role: (json['role'] as String?) ?? 'student',
      createdAt: DateTime.tryParse((json['created_at'] as String?) ?? '') ??
          DateTime.now(),
    );
  }
}

class TxRecord {
  const TxRecord({
    required this.id,
    required this.userId,
    required this.type,
    required this.status,
    required this.kg,
    required this.amount,
    required this.note,
    required this.createdAt,
  });

  final String id;
  final String userId;
  final String type;
  final String status;
  final double kg;
  final double amount;
  final String note;
  final DateTime createdAt;

  bool get isDeposit => type == TxType.deposit;
  bool get isWithdraw => type == TxType.withdraw;
  bool get isPending => status == TxStatus.pending;

  factory TxRecord.fromJson(Map<String, dynamic> json) {
    return TxRecord(
      id: json['id'] as String,
      userId: (json['user_id'] as String?) ?? '',
      type: (json['type'] as String?) ?? TxType.deposit,
      status: (json['status'] as String?) ?? TxStatus.pending,
      kg: (json['kg'] as num?)?.toDouble() ?? 0,
      amount: (json['amount'] as num?)?.toDouble() ?? 0,
      note: (json['note'] as String?) ?? '',
      createdAt: DateTime.tryParse((json['created_at'] as String?) ?? '') ??
          DateTime.now(),
    );
  }
}

class StoreStats {
  const StoreStats({
    required this.students,
    required this.totalKg,
    required this.totalBalance,
    required this.pendingCount,
    required this.pendingKg,
  });

  final int students;
  final double totalKg;
  final double totalBalance;
  final int pendingCount;
  final double pendingKg;
}

/// Business rules that every backend enforces in the same way.
class StoreRules {
  StoreRules._();

  /// Rupiah paid per approved kilogram.
  static const double pricePerKg = 2500;

  /// Smallest payout a student can request.
  static const double minWithdraw = 10000;
}

/// A one-time weighing ticket the admin creates after weighing the waste. The
/// student scans its QR code (or types the code) to turn it into balance.
class Ticket {
  const Ticket({
    required this.code,
    required this.userId,
    required this.kg,
    required this.amount,
    required this.expiresAt,
  });

  final String code;
  final String userId;
  final double kg;
  final double amount;
  final DateTime expiresAt;

  /// Text encoded into the ticket's QR code.
  String get payload => 'trashpay://ticket/$code';

  factory Ticket.fromJson(Map<String, dynamic> json) {
    return Ticket(
      code: json['code'] as String,
      userId: (json['user_id'] as String?) ?? '',
      kg: (json['kg'] as num?)?.toDouble() ?? 0,
      amount: (json['amount'] as num?)?.toDouble() ?? 0,
      expiresAt: DateTime.tryParse((json['expires_at'] as String?) ?? '') ??
          DateTime.now().add(const Duration(minutes: 10)),
    );
  }
}

class TicketCode {
  TicketCode._();

  /// Pulls the ticket code out of a scanned QR text or a typed code.
  /// Returns null when the text is not a TrashPay ticket.
  static String? parse(String raw) {
    var text = raw.trim();
    if (text.isEmpty) return null;
    const prefix = 'trashpay://ticket/';
    if (text.toLowerCase().startsWith(prefix)) {
      text = text.substring(prefix.length);
    }
    text = text.replaceAll(RegExp(r'[\s-]'), '').toUpperCase();
    return RegExp(r'^[A-Z0-9]{8,24}$').hasMatch(text) ? text : null;
  }
}
