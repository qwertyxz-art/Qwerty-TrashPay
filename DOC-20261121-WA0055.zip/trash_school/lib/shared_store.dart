import 'backend.dart';
import 'cloud_config.dart';
import 'firebase_backend.dart';
import 'models.dart';
import 'supabase_backend.dart';

export 'models.dart';

/// The one data API the screens use. It forwards to the backend chosen in
/// cloud_config.dart (Supabase or Firebase).
class SharedStore {
  SharedStore._();

  /// Rupiah paid per approved kilogram.
  static const double pricePerKg = StoreRules.pricePerKg;

  /// Smallest payout a student can request.
  static const double minWithdraw = StoreRules.minWithdraw;

  static final CloudBackend _backend =
      CloudConfig.useFirebase ? FirebaseBackend() : SupabaseBackend();

  // -------------------------------------------------------------------- auth

  static Future<AppUser> signUp({
    required String name,
    required String email,
    required String phone,
    required String ewallet,
    required String password,
  }) {
    return _backend.signUp(
      name: name,
      email: email,
      phone: phone,
      ewallet: ewallet,
      password: password,
    );
  }

  static Future<AppUser> signIn({
    required String email,
    required String password,
  }) {
    return _backend.signIn(email: email, password: password);
  }

  /// Admin sign-in with a username such as "principal".
  static Future<AppUser> signInAdmin({
    required String username,
    required String password,
  }) async {
    final name = username.trim();
    if (name.isEmpty || password.isEmpty) {
      throw StoreException('Enter your username and password.');
    }
    final email =
        name.contains('@') ? name : '$name@${CloudConfig.adminEmailDomain}';
    final user = await _backend.signIn(email: email, password: password);
    if (!user.isAdmin) {
      await _backend.signOut();
      throw StoreException('This account is not an admin account.');
    }
    return user;
  }

  /// Signed-in user from the saved session, or null when signed out.
  static Future<AppUser?> restoreSession() => _backend.restoreSession();

  static Future<void> signOut() => _backend.signOut();

  // ------------------------------------------------------------------- users

  static Future<List<AppUser>> getUsers() => _backend.getUsers();

  static Future<AppUser?> getUser(String id) => _backend.getUser(id);

  // ------------------------------------------------------------- weighings

  /// Records a weighing as PENDING. Balance only changes once an admin approves.
  /// [userId] is kept for the UI; the backend always uses the signed-in user.
  static Future<TxRecord> submitWeighing({
    required String userId,
    required double kg,
  }) {
    if (kg <= 0) {
      throw StoreException('Weight must be greater than 0 kg.');
    }
    return _backend.submitWeighing(kg);
  }

  static Future<List<TxRecord>> getPendingWeighings() =>
      _backend.getPendingWeighings();

  static Future<void> approveWeighing(String txId) =>
      _backend.reviewWeighing(txId, true);

  static Future<void> rejectWeighing(String txId) =>
      _backend.reviewWeighing(txId, false);

  // ---------------------------------------------------------- transactions

  /// Transactions (newest first). A student only ever receives their own; the
  /// admin receives everyone's unless [userId] is given.
  static Future<List<TxRecord>> getTransactions({String? userId}) =>
      _backend.getTransactions(userId: userId);

  /// Simulated payout. Withdraws [amount], or the full balance when omitted.
  static Future<TxRecord> withdraw({
    required String userId,
    double? amount,
  }) {
    return _backend.withdraw(amount);
  }

  // ----------------------------------------------------------------- stats

  static Future<StoreStats> getStats() async {
    final users = await getUsers();
    final pending = await getPendingWeighings();

    var totalKg = 0.0;
    var totalBalance = 0.0;
    for (final user in users) {
      totalKg += user.totalKg;
      totalBalance += user.balance;
    }
    var pendingKg = 0.0;
    for (final tx in pending) {
      pendingKg += tx.kg;
    }

    double round2(double v) => (v * 100).roundToDouble() / 100;
    return StoreStats(
      students: users.length,
      totalKg: round2(totalKg),
      totalBalance: round2(totalBalance),
      pendingCount: pending.length,
      pendingKg: round2(pendingKg),
    );
  }

  // --------------------------------------------------------------- tickets

  /// Admin: after weighing, creates a one-time ticket (QR) for [userId].
  static Future<Ticket> createTicket({
    required String userId,
    required double kg,
  }) {
    if (kg <= 0 || kg > 100) {
      throw StoreException('Weight must be between 0 and 100 kg.');
    }
    return _backend.createTicket(userId: userId, kg: kg);
  }

  /// Student: redeems a scanned or typed ticket. Fails without internet.
  static Future<TxRecord> claimTicket(String scanned) {
    final code = TicketCode.parse(scanned);
    if (code == null) {
      throw StoreException('This is not a TrashPay weighing QR code.');
    }
    return _backend.claimTicket(code);
  }

  // ------------------------------------------------------------------ demo

  /// Admin only: adds 2 demo students and 2 new pending weighings in the cloud.
  static Future<void> seedDemoData() => _backend.seedDemoData();
}
