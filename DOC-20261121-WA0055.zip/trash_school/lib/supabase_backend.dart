import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'backend.dart';
import 'cloud_config.dart';
import 'models.dart';

/// Supabase over plain HTTPS (Auth + PostgREST), no native plugins.
/// Money-changing actions are database functions (see supabase_setup.sql).
class SupabaseBackend implements CloudBackend {
  static const Duration _timeout = Duration(seconds: 25);

  final http.Client _client = http.Client();
  final SessionFile _file = SessionFile('trashpay_session_supabase.json');
  AuthSession? _session;

  // ---------------------------------------------------------------- plumbing

  Map<String, String> _headers({bool withSession = true}) {
    final token = withSession ? _session?.accessToken : null;
    return <String, String>{
      'apikey': CloudConfig.anonKey,
      'Authorization': 'Bearer ${token ?? CloudConfig.anonKey}',
      'Content-Type': 'application/json',
    };
  }

  String _messageOf(http.Response res) {
    try {
      final decoded = jsonDecode(utf8.decode(res.bodyBytes));
      if (decoded is Map) {
        for (final key in <String>[
          'message',
          'msg',
          'error_description',
          'error',
        ]) {
          final value = decoded[key];
          if (value is String && value.isNotEmpty) return value;
        }
      }
    } catch (_) {
      // Not JSON: fall through to the generic message.
    }
    return 'The server answered with an error (${res.statusCode}).';
  }

  dynamic _decode(http.Response res) {
    if (res.statusCode >= 200 && res.statusCode < 300) {
      if (res.bodyBytes.isEmpty) return null;
      final text = utf8.decode(res.bodyBytes).trim();
      if (text.isEmpty) return null;
      return jsonDecode(text);
    }
    throw StoreException(_messageOf(res));
  }

  Future<http.Response> _call(
    String method,
    String path, {
    Object? body,
    bool withSession = true,
  }) async {
    ensureCloudConfigured();
    final uri = Uri.parse('${CloudConfig.url}$path');
    final headers = _headers(withSession: withSession);
    try {
      if (method == 'POST') {
        return await _client
            .post(uri, headers: headers, body: jsonEncode(body ?? {}))
            .timeout(_timeout);
      }
      return await _client.get(uri, headers: headers).timeout(_timeout);
    } on TimeoutException {
      throw StoreException('The server took too long to answer. Try again.');
    } on SocketException {
      throw StoreException('No internet connection. Check your network.');
    } on http.ClientException {
      throw StoreException('No internet connection. Check your network.');
    }
  }

  /// Calls the data API with the signed-in user's token and retries once with
  /// a fresh token when the old one has expired.
  Future<dynamic> _data(String method, String path, {Object? body}) async {
    var res = await _call(method, path, body: body);
    if (res.statusCode == 401 && _session != null) {
      if (await _refresh()) {
        res = await _call(method, path, body: body);
      }
    }
    return _decode(res);
  }

  Future<dynamic> _rpc(String name, [Map<String, dynamic>? args]) {
    return _data('POST', '/rest/v1/rpc/$name', body: args ?? <String, dynamic>{});
  }

  List<Map<String, dynamic>> _rows(dynamic data) {
    if (data is List) {
      return data
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .toList();
    }
    return <Map<String, dynamic>>[];
  }

  // ----------------------------------------------------------------- session

  Future<void> _adopt(Map<String, dynamic> data) async {
    final access = data['access_token'];
    final refresh = data['refresh_token'];
    final user = data['user'];
    final userId = user is Map ? user['id'] : null;
    if (access is! String || refresh is! String || userId is! String) {
      throw StoreException('The server did not return a login session.');
    }
    final session = AuthSession(
      accessToken: access,
      refreshToken: refresh,
      userId: userId,
    );
    _session = session;
    await _file.write(session);
  }

  Future<bool> _refresh() async {
    final session = _session;
    if (session == null) return false;
    try {
      final res = await _call(
        'POST',
        '/auth/v1/token?grant_type=refresh_token',
        body: <String, dynamic>{'refresh_token': session.refreshToken},
        withSession: false,
      );
      if (res.statusCode < 200 || res.statusCode >= 300) return false;
      final data = _decode(res);
      if (data is! Map) return false;
      session.accessToken = (data['access_token'] as String?) ?? '';
      session.refreshToken =
          (data['refresh_token'] as String?) ?? session.refreshToken;
      if (session.accessToken.isEmpty) return false;
      await _file.write(session);
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<AppUser> _myProfile() async {
    final id = _session?.userId;
    if (id == null) throw StoreException('You are not signed in.');
    final rows =
        _rows(await _data('GET', '/rest/v1/profiles?select=*&id=eq.$id'));
    if (rows.isEmpty) {
      throw StoreException(
        'Your profile was not found. Run supabase_setup.sql in Supabase first.',
      );
    }
    return AppUser.fromJson(rows.first);
  }

  String _friendlyAuthError(StoreException error) {
    final text = error.message.toLowerCase();
    if (text.contains('invalid login')) {
      return 'Wrong email or password. Try again.';
    }
    if (text.contains('already registered') || text.contains('already been')) {
      return 'This email is already registered. Sign in instead.';
    }
    if (text.contains('password') && text.contains('characters')) {
      return 'Use a password with at least 6 characters.';
    }
    if (text.contains('rate limit')) {
      return 'Too many attempts. Wait a minute and try again.';
    }
    return error.message;
  }

  // -------------------------------------------------------------------- auth

  @override
  Future<AppUser> signUp({
    required String name,
    required String email,
    required String phone,
    required String ewallet,
    required String password,
  }) async {
    try {
      final res = await _call(
        'POST',
        '/auth/v1/signup',
        withSession: false,
        body: <String, dynamic>{
          'email': email.trim().toLowerCase(),
          'password': password,
          'data': <String, dynamic>{
            'name': name.trim(),
            'phone': phone.trim(),
            'ewallet': ewallet.trim(),
          },
        },
      );
      final data = _decode(res);
      if (data is! Map || data['access_token'] == null) {
        throw StoreException(
          'Account created, but Supabase still wants email confirmation. '
          'Turn off "Confirm email" (Authentication > Providers > Email).',
        );
      }
      await _adopt(Map<String, dynamic>.from(data));
      return await _myProfile();
    } on StoreException catch (error) {
      throw StoreException(_friendlyAuthError(error));
    }
  }

  @override
  Future<AppUser> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final res = await _call(
        'POST',
        '/auth/v1/token?grant_type=password',
        withSession: false,
        body: <String, dynamic>{
          'email': email.trim().toLowerCase(),
          'password': password,
        },
      );
      final data = _decode(res);
      if (data is! Map) {
        throw StoreException('The server did not return a login session.');
      }
      await _adopt(Map<String, dynamic>.from(data));
      return await _myProfile();
    } on StoreException catch (error) {
      throw StoreException(_friendlyAuthError(error));
    }
  }

  @override
  Future<AppUser?> restoreSession() async {
    if (!CloudConfig.isConfigured) return null;
    _session ??= await _file.read();
    if (_session == null) return null;
    try {
      return await _myProfile();
    } on StoreException catch (error) {
      final text = error.message.toLowerCase();
      final offline = text.contains('internet') || text.contains('too long');
      if (!offline) await signOut();
      return null;
    }
  }

  @override
  Future<void> signOut() async {
    _session = null;
    await _file.clear();
  }

  // ------------------------------------------------------------------- users

  @override
  Future<List<AppUser>> getUsers() async {
    final data = await _data(
      'GET',
      '/rest/v1/profiles?select=*&role=eq.student&order=name.asc',
    );
    return _rows(data).map(AppUser.fromJson).toList();
  }

  @override
  Future<AppUser?> getUser(String id) async {
    final data = await _data('GET', '/rest/v1/profiles?select=*&id=eq.$id');
    final rows = _rows(data);
    return rows.isEmpty ? null : AppUser.fromJson(rows.first);
  }

  // ------------------------------------------------------------- weighings

  @override
  Future<TxRecord> submitWeighing(double kg) async {
    final data = await _rpc('submit_weighing', <String, dynamic>{'p_kg': kg});
    if (data is! Map) throw StoreException('Unexpected answer from the server.');
    return TxRecord.fromJson(Map<String, dynamic>.from(data));
  }

  @override
  Future<List<TxRecord>> getPendingWeighings() async {
    final data = await _data(
      'GET',
      '/rest/v1/transactions?select=*&type=eq.deposit&status=eq.pending'
      '&order=created_at.desc&limit=500',
    );
    return _rows(data).map(TxRecord.fromJson).toList();
  }

  @override
  Future<void> reviewWeighing(String txId, bool approve) async {
    await _rpc('review_weighing', <String, dynamic>{
      'p_tx': txId,
      'p_approve': approve,
    });
  }

  // ---------------------------------------------------------- transactions

  @override
  Future<List<TxRecord>> getTransactions({String? userId}) async {
    final filter = userId == null ? '' : '&user_id=eq.$userId';
    final data = await _data(
      'GET',
      '/rest/v1/transactions?select=*&order=created_at.desc&limit=500$filter',
    );
    return _rows(data).map(TxRecord.fromJson).toList();
  }

  @override
  Future<TxRecord> withdraw(double? amount) async {
    final data = await _rpc('withdraw', <String, dynamic>{'p_amount': amount});
    if (data is! Map) throw StoreException('Unexpected answer from the server.');
    return TxRecord.fromJson(Map<String, dynamic>.from(data));
  }

  @override
  Future<void> seedDemoData() async {
    await _rpc('seed_demo_data');
  }

  // ---------------------------------------------------------------- tickets

  @override
  Future<Ticket> createTicket({
    required String userId,
    required double kg,
  }) async {
    final data = await _rpc('create_ticket', <String, dynamic>{
      'p_user': userId,
      'p_kg': kg,
    });
    if (data is! Map) throw StoreException('Unexpected answer from the server.');
    return Ticket.fromJson(Map<String, dynamic>.from(data));
  }

  @override
  Future<TxRecord> claimTicket(String code) async {
    final data = await _rpc('claim_ticket', <String, dynamic>{'p_code': code});
    if (data is! Map) throw StoreException('Unexpected answer from the server.');
    return TxRecord.fromJson(Map<String, dynamic>.from(data));
  }
}
