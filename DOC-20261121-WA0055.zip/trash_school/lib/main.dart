import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';

import 'cloud_config.dart';
import 'crash_guard.dart';
import 'format.dart';
import 'scan_screen.dart';
import 'shared_store.dart';
import 'theme.dart';
import 'update_checker.dart';
import 'widgets/widgets.dart';

void main() {
  runAppGuarded(() => const TrashSchoolApp());
}

class TrashSchoolApp extends StatelessWidget {
  const TrashSchoolApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TrashPay Schools',
      debugShowCheckedModeBanner: false,
      theme: buildNavyTheme(),
      home: const SessionGate(),
    );
  }
}

// ---------------------------------------------------------------------------
// Session gate: restores the saved student or shows the login screen.
// ---------------------------------------------------------------------------

class SessionGate extends StatefulWidget {
  const SessionGate({super.key});

  @override
  State<SessionGate> createState() => _SessionGateState();
}

class _SessionGateState extends State<SessionGate> {
  AppUser? _user;
  bool _booting = true;

  @override
  void initState() {
    super.initState();
    _restore();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        UpdateChecker.promptIfAvailable(context, apkName: 'trash_school.apk');
      }
    });
  }

  Future<void> _restore() async {
    AppUser? user;
    try {
      user = await SharedStore.restoreSession();
    } catch (_) {
      user = null;
    }
    if (!mounted) return;
    setState(() {
      _user = user;
      _booting = false;
    });
  }

  Future<void> _logout() async {
    try {
      await SharedStore.signOut();
    } catch (_) {
      // Ignore: the user is leaving the screen anyway.
    }
    if (!mounted) return;
    setState(() => _user = null);
  }

  @override
  Widget build(BuildContext context) {
    if (_booting) {
      return const Scaffold(
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: SkeletonList(count: 4),
          ),
        ),
      );
    }

    final user = _user;
    if (user == null) {
      return LoginScreen(onLoggedIn: (u) => setState(() => _user = u));
    }
    return HomeScreen(key: ValueKey<String>(user.id), user: user, onLogout: _logout);
  }
}

// ---------------------------------------------------------------------------
// Login
// ---------------------------------------------------------------------------

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.onLoggedIn});

  final ValueChanged<AppUser> onLoggedIn;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _name = TextEditingController();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _phone = TextEditingController();
  final TextEditingController _wallet = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final TextEditingController _confirm = TextEditingController();

  bool _register = true;
  bool _obscure = true;
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _phone.dispose();
    _wallet.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  void _toggleMode() {
    if (_busy) return;
    _formKey.currentState?.reset();
    setState(() => _register = !_register);
  }

  Future<void> _submit() async {
    if (_busy) return;
    FocusScope.of(context).unfocus();
    if (!(_formKey.currentState?.validate() ?? false)) return;

    setState(() => _busy = true);
    try {
      final AppUser user;
      if (_register) {
        user = await SharedStore.signUp(
          name: _name.text,
          email: _email.text,
          phone: _phone.text,
          ewallet: _wallet.text,
          password: _password.text,
        );
      } else {
        user = await SharedStore.signIn(
          email: _email.text,
          password: _password.text,
        );
      }
      if (!mounted) return;
      widget.onLoggedIn(user);
    } catch (error) {
      if (!mounted) return;
      setState(() => _busy = false);
      showAppSnack(context, '$error', error: true);
    }
  }

  Widget _passwordSuffix() {
    return PressableIconButton(
      icon: _obscure
          ? Icons.visibility_outlined
          : Icons.visibility_off_outlined,
      tooltip: _obscure ? 'Show password' : 'Hide password',
      color: AppColors.textMuted,
      onPressed: () => setState(() => _obscure = !_obscure),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 76,
                        height: 76,
                        decoration: BoxDecoration(
                          color: AppColors.accent.withAlpha(32),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: AppColors.accent.withAlpha(120),
                          ),
                        ),
                        child: const Icon(
                          Icons.recycling,
                          size: 40,
                          color: AppColors.accent,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'TrashPay Schools',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _register
                          ? 'Create your account to start earning from recyclables.'
                          : 'Welcome back. Sign in to see your balance.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(height: 28),
                    if (_register) ...[
                      TextFormField(
                        controller: _name,
                        textCapitalization: TextCapitalization.words,
                        textInputAction: TextInputAction.next,
                        decoration: appInputDecoration(
                          label: 'Name',
                          icon: Icons.person_outline,
                        ),
                        validator: (value) {
                          if (value == null || value.trim().length < 2) {
                            return 'Enter your name';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 14),
                    ],
                    TextFormField(
                      controller: _email,
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      autocorrect: false,
                      enableSuggestions: false,
                      decoration: appInputDecoration(
                        label: 'Email',
                        hint: 'name@email.com',
                        icon: Icons.mail_outline,
                      ),
                      validator: (value) {
                        final text = value?.trim() ?? '';
                        final ok = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(text);
                        return ok ? null : 'Enter a valid email address';
                      },
                    ),
                    const SizedBox(height: 14),
                    if (_register) ...[
                      TextFormField(
                        controller: _phone,
                        keyboardType: TextInputType.phone,
                        textInputAction: TextInputAction.next,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        decoration: appInputDecoration(
                          label: 'Phone',
                          hint: '08xxxxxxxxxx',
                          icon: Icons.phone_outlined,
                        ),
                        validator: (value) {
                          final digits = value?.trim() ?? '';
                          if (digits.length < 8) {
                            return 'Enter a valid phone number';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _wallet,
                        textInputAction: TextInputAction.next,
                        decoration: appInputDecoration(
                          label: 'E-wallet',
                          hint: 'e.g. DANA 08xxxxxxxxxx',
                          icon: Icons.account_balance_wallet_outlined,
                        ),
                        validator: (value) {
                          if (value == null || value.trim().length < 3) {
                            return 'Enter your e-wallet, e.g. DANA or GoPay';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 14),
                    ],
                    TextFormField(
                      controller: _password,
                      obscureText: _obscure,
                      autocorrect: false,
                      enableSuggestions: false,
                      textInputAction:
                          _register ? TextInputAction.next : TextInputAction.done,
                      onFieldSubmitted: (_) {
                        if (!_register) _submit();
                      },
                      decoration: appInputDecoration(
                        label: 'Password',
                        icon: Icons.lock_outline,
                        suffix: _passwordSuffix(),
                      ),
                      validator: (value) {
                        if (value == null || value.length < 6) {
                          return 'Use at least 6 characters';
                        }
                        return null;
                      },
                    ),
                    if (_register) ...[
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _confirm,
                        obscureText: _obscure,
                        autocorrect: false,
                        enableSuggestions: false,
                        textInputAction: TextInputAction.done,
                        onFieldSubmitted: (_) => _submit(),
                        decoration: appInputDecoration(
                          label: 'Confirm password',
                          icon: Icons.lock_outline,
                        ),
                        validator: (value) {
                          if (value != _password.text) {
                            return 'Passwords do not match';
                          }
                          return null;
                        },
                      ),
                    ],
                    const SizedBox(height: 24),
                    AnimatedButton(
                      label: _register ? 'Create account' : 'Sign in',
                      icon: _register ? Icons.person_add_alt_1 : Icons.login,
                      loading: _busy,
                      onPressed: _submit,
                    ),
                    const SizedBox(height: 12),
                    AnimatedButton(
                      label: _register
                          ? 'I already have an account'
                          : 'Create a new account',
                      style: AppButtonStyle.outlined,
                      onPressed: _busy ? null : _toggleMode,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Home
// ---------------------------------------------------------------------------

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.user, required this.onLogout});

  final AppUser user;
  final VoidCallback onLogout;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late AppUser _user;
  double _pendingKg = 0;
  bool _loading = true;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _user = widget.user;
    _load(first: true);
  }

  Future<void> _load({bool first = false}) async {
    if (first) {
      // Short pause so the shimmer skeleton is visible on first open.
      await Future<void>.delayed(const Duration(milliseconds: 600));
    }
    try {
      final fresh = await SharedStore.getUser(_user.id);
      final txs = await SharedStore.getTransactions(userId: _user.id);
      var pending = 0.0;
      for (final tx in txs) {
        if (tx.isDeposit && tx.isPending) pending += tx.kg;
      }
      if (!mounted) return;
      setState(() {
        if (fresh != null) _user = fresh;
        _pendingKg = pending;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      showAppSnack(context, 'Could not load your data: $error', error: true);
    }
  }

  // --- actions -------------------------------------------------------------

  /// Scans the QR ticket the admin shows after weighing and credits it.
  Future<void> _scanTicket() async {
    if (_busy) return;
    final tx = await Navigator.of(context).push<TxRecord>(
      MaterialPageRoute<TxRecord>(builder: (_) => const ScanScreen()),
    );
    if (tx == null || !mounted) return;
    showAppSnack(
      context,
      'Weighing added: ${formatKg(tx.kg)} = ${formatRupiah(tx.amount)}.',
    );
    await _load();
  }

  Future<void> _simulateScan() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => const _ScanDialog(),
      );
      final tx = await SharedStore.submitWeighing(userId: _user.id, kg: 5.0);
      await _load();
      if (!mounted) return;
      showAppSnack(
        context,
        'Scan complete. ${formatKg(tx.kg)} is waiting for admin approval.',
      );
    } catch (error) {
      if (!mounted) return;
      showAppSnack(context, 'Scan failed: $error', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _showTransactions() {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _TransactionsSheet(userId: _user.id),
    );
  }

  Future<void> _withdraw() async {
    if (_busy) return;
    final balance = _user.balance;
    if (balance < SharedStore.minWithdraw) {
      showAppSnack(
        context,
        'Withdrawals start at ${formatRupiah(SharedStore.minWithdraw)}. '
        'Your balance is ${formatRupiah(balance)}.',
        error: true,
      );
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => _WithdrawDialog(amount: balance, ewallet: _user.ewallet),
    );
    if (confirmed != true || !mounted) return;

    setState(() => _busy = true);
    try {
      // Simulated payout processing time.
      await Future<void>.delayed(const Duration(milliseconds: 900));
      final tx = await SharedStore.withdraw(userId: _user.id);
      await _load();
      if (!mounted) return;
      showAppSnack(
        context,
        '${formatRupiah(tx.amount)} sent to ${_user.ewallet} (simulated).',
      );
    } catch (error) {
      if (!mounted) return;
      showAppSnack(context, 'Withdrawal failed: $error', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showMyQr() {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return Dialog(
          backgroundColor: AppColors.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _user.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Show this code to the school waste bank',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.textMuted),
                ),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: QrImageView(
                    data: _user.qrPayload,
                    version: QrVersions.auto,
                    size: 220,
                    padding: EdgeInsets.zero,
                    backgroundColor: Colors.white,
                  ),
                ),
                const SizedBox(height: 20),
                AnimatedButton(
                  label: 'Close',
                  style: AppButtonStyle.outlined,
                  onPressed: () => Navigator.of(dialogContext).pop(),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // --- build ---------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('TrashPay Schools'),
        actions: [
          PressableIconButton(
            icon: Icons.qr_code_2,
            tooltip: 'My QR code',
            onPressed: _loading ? null : _showMyQr,
          ),
          PressableIconButton(
            icon: Icons.logout,
            tooltip: 'Log out',
            onPressed: widget.onLogout,
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.accent,
          backgroundColor: AppColors.surface,
          onRefresh: () => _load(),
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
            children: _loading ? const [_HomeSkeleton()] : _content(),
          ),
        ),
      ),
    );
  }

  List<Widget> _content() {
    return [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1B2A6B), AppColors.surface],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Hi, ${_user.name}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: AppColors.textMuted, fontSize: 15),
            ),
            const SizedBox(height: 10),
            const Text(
              'Balance',
              style: TextStyle(color: AppColors.textMuted, fontSize: 13),
            ),
            const SizedBox(height: 2),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(
                formatRupiah(_user.balance),
                style: const TextStyle(
                  color: AppColors.accent,
                  fontSize: 36,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: _MiniStat(
                    icon: Icons.scale_outlined,
                    label: 'Total kg',
                    value: formatKg(_user.totalKg),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _MiniStat(
                    icon: Icons.hourglass_top,
                    label: 'Pending',
                    value: formatKg(_pendingKg),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      const SizedBox(height: 14),
      AppCard(
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: AppColors.accent.withAlpha(32),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Icon(
                Icons.account_balance_wallet_outlined,
                color: AppColors.accent,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'E-wallet',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _user.ewallet,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Phone ${_user.phone}',
                    style: const TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 22),
      AnimatedButton(
        label: 'Scan Weighing QR',
        icon: Icons.qr_code_scanner,
        onPressed: _busy ? null : _scanTicket,
      ),
      if (CloudConfig.demoMode) ...[
        const SizedBox(height: 12),
        AnimatedButton(
          label: 'Simulate QR Scan',
          icon: Icons.bolt,
          style: AppButtonStyle.tonal,
          loading: _busy,
          onPressed: _simulateScan,
        ),
      ],
      const SizedBox(height: 12),
      AnimatedButton(
        label: 'History',
        icon: Icons.receipt_long_outlined,
        style: AppButtonStyle.outlined,
        onPressed: _showTransactions,
      ),
      const SizedBox(height: 12),
      AnimatedButton(
        label: 'Withdraw',
        icon: Icons.payments_outlined,
        style: AppButtonStyle.tonal,
        onPressed: _busy ? null : _withdraw,
      ),
      const SizedBox(height: 18),
      Text(
        'Each approved kg earns ${formatRupiah(SharedStore.pricePerKg)}. '
        'Withdrawals start at ${formatRupiah(SharedStore.minWithdraw)}.',
        textAlign: TextAlign.center,
        style: const TextStyle(color: AppColors.textMuted, fontSize: 13),
      ),
    ];
  }
}

class _HomeSkeleton extends StatelessWidget {
  const _HomeSkeleton();

  @override
  Widget build(BuildContext context) {
    return const Shimmer(
      child: Column(
        children: [
          SkeletonBox(height: 190, radius: 24),
          SizedBox(height: 14),
          SkeletonBox(height: 84, radius: 20),
          SizedBox(height: 22),
          SkeletonBox(height: 54),
          SizedBox(height: 12),
          SkeletonBox(height: 54),
          SizedBox(height: 12),
          SkeletonBox(height: 54),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.background.withAlpha(120),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.accent),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Simulated QR scan dialog
// ---------------------------------------------------------------------------

class _ScanDialog extends StatefulWidget {
  const _ScanDialog();

  @override
  State<_ScanDialog> createState() => _ScanDialogState();
}

class _ScanDialogState extends State<_ScanDialog>
    with SingleTickerProviderStateMixin {
  static const double _frame = 180;

  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);

    Future<void>.delayed(const Duration(milliseconds: 1800), () {
      if (mounted) Navigator.of(context).pop();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppColors.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: _frame,
              height: _frame,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppColors.accent, width: 2),
                      ),
                      child: Icon(
                        Icons.qr_code_2,
                        size: 120,
                        color: AppColors.text.withAlpha(70),
                      ),
                    ),
                  ),
                  AnimatedBuilder(
                    animation: _controller,
                    builder: (context, _) {
                      return Positioned(
                        top: 10 + _controller.value * (_frame - 24),
                        left: 12,
                        right: 12,
                        child: Container(
                          height: 3,
                          decoration: BoxDecoration(
                            color: AppColors.accent,
                            borderRadius: BorderRadius.circular(2),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.accent.withAlpha(170),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Scanning QR code',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 4),
            const Text(
              'Simulated scan: 5.0 kg of waste',
              style: TextStyle(color: AppColors.textMuted),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Withdraw confirmation dialog
// ---------------------------------------------------------------------------

class _WithdrawDialog extends StatelessWidget {
  const _WithdrawDialog({required this.amount, required this.ewallet});

  final double amount;
  final String ewallet;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppColors.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Withdraw balance',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 12),
            Text(
              formatRupiah(amount),
              style: const TextStyle(
                color: AppColors.accent,
                fontSize: 30,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Will be sent to $ewallet. This is a simulated payout.',
              style: const TextStyle(color: AppColors.textMuted),
            ),
            const SizedBox(height: 22),
            Row(
              children: [
                Expanded(
                  child: AnimatedButton(
                    label: 'Cancel',
                    style: AppButtonStyle.outlined,
                    onPressed: () => Navigator.of(context).pop(false),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: AnimatedButton(
                    label: 'Withdraw',
                    onPressed: () => Navigator.of(context).pop(true),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Transactions bottom sheet
// ---------------------------------------------------------------------------

class _TransactionsSheet extends StatefulWidget {
  const _TransactionsSheet({required this.userId});

  final String userId;

  @override
  State<_TransactionsSheet> createState() => _TransactionsSheetState();
}

class _TransactionsSheetState extends State<_TransactionsSheet> {
  List<TxRecord> _items = const <TxRecord>[];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      await Future<void>.delayed(const Duration(milliseconds: 500));
      final items = await SharedStore.getTransactions(userId: widget.userId);
      if (!mounted) return;
      setState(() {
        _items = items;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.72,
      minChildSize: 0.45,
      maxChildSize: 0.95,
      builder: (context, controller) {
        return Column(
          children: [
            const SheetHandle(),
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 12),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'History',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                ),
              ),
            ),
            Expanded(child: _body(controller)),
          ],
        );
      },
    );
  }

  Widget _body(ScrollController controller) {
    const padding = EdgeInsets.fromLTRB(20, 4, 20, 28);

    if (_loading) {
      return ListView(
        controller: controller,
        padding: padding,
        children: const [SkeletonList(count: 5)],
      );
    }

    if (_error != null) {
      return ListView(
        controller: controller,
        padding: padding,
        children: [
          _EmptyNote(
            icon: Icons.error_outline,
            text: 'Could not load transactions: $_error',
          ),
        ],
      );
    }

    if (_items.isEmpty) {
      return ListView(
        controller: controller,
        padding: padding,
        children: const [
          _EmptyNote(
            icon: Icons.receipt_long_outlined,
            text: 'No transactions yet. Tap Simulate QR Scan to add your first 5.0 kg.',
          ),
        ],
      );
    }

    return ListView.separated(
      controller: controller,
      padding: padding,
      itemCount: _items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) => _TxTile(tx: _items[index]),
    );
  }
}

class _EmptyNote extends StatelessWidget {
  const _EmptyNote({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 12),
      child: Column(
        children: [
          Icon(icon, size: 44, color: AppColors.textMuted),
          const SizedBox(height: 14),
          Text(
            text,
            textAlign: TextAlign.center,
            style: const TextStyle(color: AppColors.textMuted, fontSize: 15),
          ),
        ],
      ),
    );
  }
}

class _TxTile extends StatelessWidget {
  const _TxTile({required this.tx});

  final TxRecord tx;

  @override
  Widget build(BuildContext context) {
    final Color tone;
    final IconData icon;
    final String statusLabel;
    final String title;
    final String amountText;

    if (tx.isWithdraw) {
      tone = AppColors.accent;
      icon = Icons.north_east;
      statusLabel = 'Paid out';
      title = 'Withdrawal';
      amountText = '-${formatRupiah(tx.amount)}';
    } else if (tx.status == TxStatus.approved) {
      tone = AppColors.success;
      icon = Icons.check_circle_outline;
      statusLabel = 'Approved';
      title = 'Waste ${formatKg(tx.kg)}';
      amountText = '+${formatRupiah(tx.amount)}';
    } else if (tx.status == TxStatus.rejected) {
      tone = AppColors.danger;
      icon = Icons.cancel_outlined;
      statusLabel = 'Rejected';
      title = 'Waste ${formatKg(tx.kg)}';
      amountText = formatRupiah(tx.amount);
    } else {
      tone = AppColors.warning;
      icon = Icons.hourglass_top;
      statusLabel = 'Pending approval';
      title = 'Waste ${formatKg(tx.kg)}';
      amountText = formatRupiah(tx.amount);
    }

    final rejected = tx.status == TxStatus.rejected;

    return AppCard(
      padding: const EdgeInsets.all(14),
      radius: 18,
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: tone.withAlpha(34),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: tone, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 3),
                Text(
                  formatDateTime(tx.createdAt),
                  style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                amountText,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: rejected ? AppColors.textMuted : AppColors.text,
                  decoration: rejected ? TextDecoration.lineThrough : null,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                statusLabel,
                style: TextStyle(color: tone, fontSize: 12, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
