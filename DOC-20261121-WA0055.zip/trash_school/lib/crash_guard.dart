import 'dart:async';

import 'package:flutter/material.dart';

import 'theme.dart';

/// Starts the app inside an error zone. Any widget that fails to build shows
/// the error text on a navy screen (easy to screenshot) instead of a blank
/// grey box, and uncaught async errors are logged instead of lost.
void runAppGuarded(Widget Function() buildApp) {
  runZonedGuarded<void>(
    () {
      WidgetsFlutterBinding.ensureInitialized();
      ErrorWidget.builder = _buildErrorWidget;
      runApp(buildApp());
    },
    (Object error, StackTrace stackTrace) {
      debugPrint('Uncaught error: $error\n$stackTrace');
    },
  );
}

Widget _buildErrorWidget(FlutterErrorDetails details) {
  return Directionality(
    textDirection: TextDirection.ltr,
    child: Container(
      color: AppColors.background,
      padding: const EdgeInsets.all(20),
      alignment: Alignment.center,
      child: Text(
        'Something went wrong:\n${details.exceptionAsString()}',
        maxLines: 12,
        overflow: TextOverflow.ellipsis,
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: AppColors.text,
          fontSize: 13,
          fontWeight: FontWeight.w500,
          decoration: TextDecoration.none,
        ),
      ),
    ),
  );
}
