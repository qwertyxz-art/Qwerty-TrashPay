import 'package:flutter/material.dart';

import '../theme.dart';
import 'pressable_scale.dart';

enum AppButtonStyle { filled, tonal, outlined, danger }

/// Primary button of both apps. Every press scales to 0.96 and fades to 75%.
class AnimatedButton extends StatelessWidget {
  const AnimatedButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.style = AppButtonStyle.filled,
    this.loading = false,
    this.expand = true,
    this.dense = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final AppButtonStyle style;
  final bool loading;
  final bool expand;
  final bool dense;

  @override
  Widget build(BuildContext context) {
    final disabled = onPressed == null;
    final enabled = !disabled && !loading;

    late final Color background;
    late final Color foreground;
    Color? borderColor;

    switch (style) {
      case AppButtonStyle.filled:
        background = AppColors.accent;
        foreground = AppColors.background;
        break;
      case AppButtonStyle.tonal:
        background = AppColors.surfaceHigh;
        foreground = AppColors.accent;
        break;
      case AppButtonStyle.outlined:
        background = Colors.transparent;
        foreground = AppColors.accent;
        borderColor = AppColors.accent.withAlpha(150);
        break;
      case AppButtonStyle.danger:
        background = AppColors.danger.withAlpha(30);
        foreground = AppColors.danger;
        borderColor = AppColors.danger.withAlpha(140);
        break;
    }

    final double fontSize = dense ? 13 : 16;
    final double iconSize = dense ? 16 : 20;

    final Widget leading;
    if (loading) {
      leading = SizedBox(
        width: iconSize,
        height: iconSize,
        child: CircularProgressIndicator(strokeWidth: 2.2, color: foreground),
      );
    } else if (icon != null) {
      leading = Icon(icon, size: iconSize, color: foreground);
    } else {
      leading = const SizedBox.shrink();
    }
    final hasLeading = loading || icon != null;

    final labelText = Text(
      label,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        color: foreground,
        fontSize: fontSize,
        fontWeight: FontWeight.w700,
      ),
    );

    final content = Container(
      width: expand ? double.infinity : null,
      padding: EdgeInsets.symmetric(
        vertical: dense ? 9 : 15,
        horizontal: dense ? 12 : 20,
      ),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(dense ? 12 : 14),
        border: borderColor == null
            ? null
            : Border.all(color: borderColor, width: 1.4),
      ),
      child: Row(
        mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (hasLeading) ...[
            leading,
            SizedBox(width: dense ? 6 : 10),
          ],
          // A Flexible child needs bounded width, so it is only used when the
          // button stretches (expand: true). Compact buttons just size to text.
          if (expand) Flexible(child: labelText) else labelText,
        ],
      ),
    );

    return Semantics(
      button: true,
      enabled: enabled,
      label: label,
      child: PressableScale(
        enabled: enabled,
        onPressed: onPressed,
        child: Opacity(opacity: disabled ? 0.45 : 1.0, child: content),
      ),
    );
  }
}
