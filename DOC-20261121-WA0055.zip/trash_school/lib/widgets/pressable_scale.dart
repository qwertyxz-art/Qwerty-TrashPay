import 'package:flutter/material.dart';

import '../theme.dart';

/// Wraps any widget with the app-wide press animation:
/// scales down to 0.96 and fades to 75% while pressed.
class PressableScale extends StatefulWidget {
  const PressableScale({
    super.key,
    required this.child,
    required this.onPressed,
    this.enabled = true,
  });

  final Widget child;
  final VoidCallback? onPressed;
  final bool enabled;

  static const double pressedScale = 0.96;
  static const double pressedOpacity = 0.75;

  @override
  State<PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<PressableScale> {
  static const Duration _animation = Duration(milliseconds: 110);
  static const Duration _minHold = Duration(milliseconds: 90);

  bool _down = false;
  DateTime? _downAt;

  bool get _active => widget.enabled && widget.onPressed != null;

  void _setDown(bool value) {
    if (!mounted || _down == value) return;
    setState(() => _down = value);
  }

  void _handleDown() {
    _downAt = DateTime.now();
    _setDown(true);
  }

  // Keep the pressed look visible for a moment so very quick taps still show it.
  Future<void> _handleRelease() async {
    final started = _downAt;
    if (started != null) {
      final elapsed = DateTime.now().difference(started);
      if (elapsed < _minHold) {
        await Future<void>.delayed(_minHold - elapsed);
      }
    }
    _setDown(false);
  }

  @override
  Widget build(BuildContext context) {
    final active = _active;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: active ? (_) => _handleDown() : null,
      onTapUp: active ? (_) => _handleRelease() : null,
      onTapCancel: active ? _handleRelease : null,
      onTap: active ? widget.onPressed : null,
      child: AnimatedScale(
        scale: _down ? PressableScale.pressedScale : 1.0,
        duration: _animation,
        curve: Curves.easeOut,
        child: AnimatedOpacity(
          opacity: _down ? PressableScale.pressedOpacity : 1.0,
          duration: _animation,
          curve: Curves.easeOut,
          child: widget.child,
        ),
      ),
    );
  }
}

/// Icon-only button (used in app bars) with the same press animation.
class PressableIconButton extends StatelessWidget {
  const PressableIconButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.tooltip,
    this.color,
  });

  final IconData icon;
  final VoidCallback? onPressed;
  final String? tooltip;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final button = Semantics(
      button: true,
      label: tooltip,
      child: PressableScale(
        onPressed: onPressed,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(icon, color: color ?? AppColors.text, size: 24),
        ),
      ),
    );
    final message = tooltip;
    if (message == null) return button;
    return Tooltip(message: message, child: button);
  }
}
