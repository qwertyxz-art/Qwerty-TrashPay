/// Cloud settings. Choose ONE backend and fill in its values, either here or at
/// build time with --dart-define (for example
/// `--dart-define=BACKEND=firebase --dart-define=FIREBASE_API_KEY=...`).
///
/// Supabase: Project Settings > API (Project URL and anon public key).
/// Firebase: Project settings > General (Project ID and Web API Key).
///
/// These values are meant to be public. What a signed-in user may read or write
/// is decided by supabase_setup.sql or firestore.rules.
class CloudConfig {
  CloudConfig._();

  /// 'supabase' or 'firebase'.
  static const String backend = String.fromEnvironment(
    'BACKEND',
    defaultValue: 'supabase',
  );

  static bool get useFirebase => backend == 'firebase';

  // ---- Supabase
  static const String url = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://YOUR-PROJECT-REF.supabase.co',
  );

  static const String anonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'YOUR-ANON-KEY',
  );

  // ---- Firebase
  static const String firebaseProjectId = String.fromEnvironment(
    'FIREBASE_PROJECT_ID',
    defaultValue: 'YOUR-FIREBASE-PROJECT-ID',
  );

  static const String firebaseApiKey = String.fromEnvironment(
    'FIREBASE_API_KEY',
    defaultValue: 'YOUR-FIREBASE-API-KEY',
  );

  /// The admin signs in with a username. It is turned into this email address
  /// (principal -> principal@trashpay.school), the same one you create in the
  /// Supabase or Firebase console (see README).
  static const String adminEmailDomain = 'trashpay.school';

  /// Keeps the "Simulate QR Scan" demo button in the student app. Set it to
  /// false (or build with --dart-define=DEMO_MODE=false) for real use, so
  /// weight can only come from a QR ticket the admin made after weighing.
  static const bool demoMode = bool.fromEnvironment(
    'DEMO_MODE',
    defaultValue: true,
  );

  static bool get isConfigured {
    if (useFirebase) {
      return !firebaseProjectId.startsWith('YOUR-') &&
          !firebaseApiKey.startsWith('YOUR-');
    }
    return !url.contains('YOUR-PROJECT-REF') && !anonKey.startsWith('YOUR-');
  }
}
