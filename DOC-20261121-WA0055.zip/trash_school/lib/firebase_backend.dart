import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:http/http.dart' as http;

import 'backend.dart';
import 'cloud_config.dart';
import 'models.dart';

/// One Firestore document as returned by the REST API.
class _Doc {
  _Doc(this.id, this.fields, this.updateTime);

  final String id;
  final Map<String, dynamic> fields;
  final String updateTime;

  factory _Doc.from(Map<String, dynamic> json) {
    final name = (json['name'] as String?) ?? '';
    final raw = json['fields'];
    return _Doc(
      name.split('/').last,
      raw is Map ? Map<String, dynamic>.from(raw) : <String, dynamic>{},
      (json['updateTime'] as String?) ?? '',
    );
  }

  String str(String key) {
    final value = fields[key];
    if (value is Map && value['stringValue'] is String) {
      return value['stringValue'] as String;
    }
    return '';
  }

  double dbl(String key) {
    final value = fields[key];
    if (value is! Map) return 0;
    final d = value['doubleValue'];
    if (d is num) return d.toDouble();
    final i = value['integerValue'];
    if (i is String) return double.tryParse(i) ?? 0;
    if (i is num) return i.toDouble();
    return 0;
  }

  DateTime time(String key) {
    final value = fields[key];
    if (value is Map && value['timestampValue'] is String) {
      return DateTime.tryParse(value['timestampValue'] as String) ??
          DateTime.now();
    }
    return DateTime.now();
  }
}

Map<String, dynamic> _s(String value) => <String, dynamic>{'stringValue': value};

Map<String, dynamic> _d(double value) => <String, dynamic>{'doubleValue': value};

Map<String, dynamic> _t(DateTime value) =>
    <String, dynamic>{'timestampValue': value.toUtc().toIso8601String()};

/// Firebase (Authentication + Cloud Firestore) over the public REST APIs, so no
/// native plugin and no google-services.json are needed. Who may read or write
/// what is decided by firestore.rules.
class FirebaseBackend implements CloudBackend {
  static const Duration _timeout = Duration(seconds: 25);
  static const String _alphabet =
      'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  // No 0/O/1/I so a code is easy to read out and type.
  static const String _codeAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  static const Duration _ticketLife = Duration(minutes: 10);

  final http.Client _client = http.Client();
  final SessionFile _file = SessionFile('trashpay_session_firebase.json');
  final Random _random = Random.secure();
  AuthSession? _session;

  String get _docsRoot =>
      'projects/${CloudConfig.firebaseProjectId}/databases/(default)/documents';

  String get _base => 'https://firestore.googleapis.com/v1/$_docsRoot';

  String _docName(String collection, String id) => '$_docsRoot/$collection/$id';

  String _newId() {
    final buffer = StringBuffer();
    for (var i = 0; i < 20; i++) {
      buffer.write(_alphabet[_random.nextInt(_alphabet.length)]);
    }
    return buffer.toString();
  }

  String _newCode() {
    final buffer = StringBuffer();
    for (var i = 0; i < 10; i++) {
      buffer.write(_codeAlphabet[_random.nextInt(_codeAlphabet.length)]);
    }
    return buffer.toString();
  }

  // ---------------------------------------------------------------- plumbing

  String _friendly(String raw) {
    final t = raw.toUpperCase();
    if (t.contains('EMAIL_EXISTS')) {
      return 'This email is already registered. Sign in instead.';
    }
    if (t.contains('INVALID_LOGIN_CREDENTIALS') ||
        t.contains('INVALID_PASSWORD') ||
        t.contains('EMAIL_NOT_FOUND')) {
      return 'Wrong email or password. Try again.';
    }
    if (t.contains('WEAK_PASSWORD')) {
      return 'Use a password with at least 6 characters.';
    }
    if (t.contains('TOO_MANY_ATTEMPTS')) {
      return 'Too many attempts. Wait a minute and try again.';
    }
    if (t.contains('OPERATION_NOT_ALLOWED')) {
      return 'Email/password sign-in is turned off in Firebase '
          '(Authentication > Sign-in method).';
    }
    if (t.contains('INVALID_EMAIL')) return 'Enter a valid email address.';
    if (t.contains('API_KEY_INVALID') || t.contains('API KEY NOT VALID')) {
      return 'The Firebase API key is wrong. Check lib/cloud_config.dart.';
    }
    if (t.contains('PERMISSIONS') || t.contains('PERMISSION_DENIED')) {
      return 'Not allowed by the Firestore rules. Publish firestore.rules '
          '(see README).';
    }
    if (t.contains('FAILED_PRECONDITION') || t.contains('STORED VERSION')) {
      return 'This item just changed. Refresh and try again.';
    }
    return raw;
  }

  String _messageOf(http.Response res) {
    try {
      final decoded = jsonDecode(utf8.decode(res.bodyBytes));
      if (decoded is Map) {
        final error = decoded['error'];
        if (error is Map) {
          final message = error['message'];
          if (message is String && message.isNotEmpty) return message;
          final status = error['status'];
          if (status is String && status.isNotEmpty) return status;
        }
        if (error is String && error.isNotEmpty) return error;
      }
    } catch (_) {
      // Not JSON: fall through to the generic message.
    }
    return 'The server answered with an error (${res.statusCode}).';
  }

  dynamic _decode(http.Response res) {
    if (res.statusCode >= 200 && res.statusCode < 300) {
      if (res.bodyBytes.isEmpty) return null;
      final text = utf8.decode(res.bodyBytes).trim();
      if (text.isEmpty) return null;
      return jsonDecode(text);
    }
    throw StoreException(_friendly(_messageOf(res)));
  }

  Future<http.Response> _send(
    String method,
    String url, {
    Object? body,
    bool authed = true,
  }) async {
    ensureCloudConfigured();
    final headers = <String, String>{'Content-Type': 'application/json'};
    final session = _session;
    if (authed && session != null) {
      headers['Authorization'] = 'Bearer ${session.accessToken}';
    }
    final uri = Uri.parse(url);
    try {
      if (method == 'POST') {
        return await _client
            .post(uri, headers: headers, body: jsonEncode(body ?? {}))
            .timeout(_timeout);
      }
      return await _client.get(uri, headers: headers).timeout(_timeout);
    } on TimeoutException {
      throw StoreException('The server took too long to answer. Try again.');
    } on SocketException {
      throw StoreException('No internet connection. Check your network.');
    } on http.ClientException {
      throw StoreException('No internet connection. Check your network.');
    }
  }

  /// Firestore call with the signed-in user's token; retries once with a fresh
  /// token when the old one has expired.
  Future<http.Response> _fsRaw(String method, String path, {Object? body}) async {
    var res = await _send(method, '$_base$path', body: body);
    if (res.statusCode == 401 && _session != null && await _refresh()) {
      res = await _send(method, '$_base$path', body: body);
    }
    return res;
  }

  Future<dynamic> _fs(String method, String path, {Object? body}) async {
    return _decode(await _fsRaw(method, path, body: body));
  }

  Future<dynamic> _auth(String endpoint, Map<String, dynamic> body) async {
    final res = await _send(
      'POST',
      'https://identitytoolkit.googleapis.com/v1/$endpoint'
      '?key=${CloudConfig.firebaseApiKey}',
      body: body,
      authed: false,
    );
    return _decode(res);
  }

  // ------------------------------------------------------------- documents

  Future<_Doc?> _getDoc(String collection, String id) async {
    final res = await _fsRaw('GET', '/$collection/$id');
    if (res.statusCode == 404) return null;
    final data = _decode(res);
    return data is Map ? _Doc.from(Map<String, dynamic>.from(data)) : null;
  }

  Future<List<_Doc>> _query(
    String collection, {
    List<List<String>> equals = const <List<String>>[],
    int limit = 500,
  }) async {
    final filters = <Map<String, dynamic>>[
      for (final pair in equals)
        <String, dynamic>{
          'fieldFilter': <String, dynamic>{
            'field': <String, dynamic>{'fieldPath': pair[0]},
            'op': 'EQUAL',
            'value': _s(pair[1]),
          },
        },
    ];
    final structured = <String, dynamic>{
      'from': <Map<String, dynamic>>[
        <String, dynamic>{'collectionId': collection},
      ],
      'limit': limit,
    };
    if (filters.length == 1) {
      structured['where'] = filters.first;
    } else if (filters.length > 1) {
      structured['where'] = <String, dynamic>{
        'compositeFilter': <String, dynamic>{'op': 'AND', 'filters': filters},
      };
    }
    final data = await _fs(
      'POST',
      ':runQuery',
      body: <String, dynamic>{'structuredQuery': structured},
    );
    final docs = <_Doc>[];
    if (data is List) {
      for (final item in data) {
        if (item is Map && item['document'] is Map) {
          docs.add(_Doc.from(Map<String, dynamic>.from(item['document'] as Map)));
        }
      }
    }
    return docs;
  }

  /// One write of an atomic commit. [mask] null writes every given field
  /// (a new document); an empty [mask] writes none (transforms only).
  Map<String, dynamic> _write(
    String collection,
    String id, {
    Map<String, dynamic>? fields,
    List<String>? mask,
    List<Map<String, dynamic>>? increments,
    Map<String, dynamic>? precondition,
  }) {
    final write = <String, dynamic>{
      'update': <String, dynamic>{
        'name': _docName(collection, id),
        'fields': fields ?? <String, dynamic>{},
      },
    };
    if (mask != null) {
      write['updateMask'] = <String, dynamic>{'fieldPaths': mask};
    }
    if (increments != null && increments.isNotEmpty) {
      write['updateTransforms'] = increments;
    }
    if (precondition != null) write['currentDocument'] = precondition;
    return write;
  }

  Map<String, dynamic> _increment(String field, double by) =>
      <String, dynamic>{
        'fieldPath': field,
        'increment': _d(by),
      };

  Future<void> _commit(List<Map<String, dynamic>> writes) async {
    await _fs(
      'POST',
      ':commit',
      body: <String, dynamic>{'writes': writes},
    );
  }

  // ------------------------------------------------------------- converters

  AppUser _toUser(_Doc doc) {
    final role = doc.str('role');
    return AppUser(
      id: doc.id,
      name: doc.str('name'),
      phone: doc.str('phone'),
      ewallet: doc.str('ewallet'),
      balance: doc.dbl('balance'),
      totalKg: doc.dbl('totalKg'),
      role: role.isEmpty ? 'student' : role,
      createdAt: doc.time('createdAt'),
    );
  }

  TxRecord _toTx(_Doc doc) {
    final type = doc.str('type');
    final status = doc.str('status');
    return TxRecord(
      id: doc.id,
      userId: doc.str('userId'),
      type: type.isEmpty ? TxType.deposit : type,
      status: status.isEmpty ? TxStatus.pending : status,
      kg: doc.dbl('kg'),
      amount: doc.dbl('amount'),
      note: doc.str('note'),
      createdAt: doc.time('createdAt'),
    );
  }

  List<TxRecord> _sortedTx(List<_Doc> docs) {
    final list = docs.map(_toTx).toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  // ----------------------------------------------------------------- session

  String _requireUid() {
    final id = _session?.userId;
    if (id == null) throw StoreException('You are not signed in.');
    return id;
  }

  Future<void> _adopt(dynamic data) async {
    if (data is! Map) {
      throw StoreException('The server did not return a login session.');
    }
    final access = data['idToken'];
    final refresh = data['refreshToken'];
    final userId = data['localId'];
    if (access is! String || refresh is! String || userId is! String) {
      throw StoreException('The server did not return a login session.');
    }
    final session = AuthSession(
      accessToken: access,
      refreshToken: refresh,
      userId: userId,
    );
    _session = session;
    await _file.write(session);
  }

  Future<bool> _refresh() async {
    final session = _session;
    if (session == null) return false;
    try {
      final res = await _client.post(
        Uri.parse(
          'https://securetoken.googleapis.com/v1/token'
          '?key=${CloudConfig.firebaseApiKey}',
        ),
        body: <String, String>{
          'grant_type': 'refresh_token',
          'refresh_token': session.refreshToken,
        },
      ).timeout(_timeout);
      if (res.statusCode < 200 || res.statusCode >= 300) return false;
      final data = jsonDecode(utf8.decode(res.bodyBytes));
      if (data is! Map) return false;
      final id = data['id_token'];
      final refresh = data['refresh_token'];
      if (id is! String || id.isEmpty) return false;
      session.accessToken = id;
      if (refresh is String && refresh.isNotEmpty) {
        session.refreshToken = refresh;
      }
      await _file.write(session);
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _createProfile({
    required String uid,
    required String name,
    required String phone,
    required String ewallet,
  }) async {
    await _fs(
      'POST',
      '/users?documentId=$uid',
      body: <String, dynamic>{
        'fields': <String, dynamic>{
          'name': _s(name),
          'phone': _s(phone),
          'ewallet': _s(ewallet),
          'role': _s('student'),
          'balance': _d(0),
          'totalKg': _d(0),
          'createdAt': _t(DateTime.now()),
        },
      },
    );
  }

  /// The signed-in user's profile. When the account exists but its profile
  /// does not (registration was interrupted), a basic one is created.
  Future<AppUser> _myProfile({String? emailHint}) async {
    final uid = _requireUid();
    var doc = await _getDoc('users', uid);
    if (doc == null) {
      final local = (emailHint ?? '').split('@').first;
      await _createProfile(
        uid: uid,
        name: local.isEmpty ? 'Student' : local,
        phone: '',
        ewallet: '',
      );
      doc = await _getDoc('users', uid);
    }
    if (doc == null) {
      throw StoreException(
        'Your profile was not found. Publish firestore.rules first (see README).',
      );
    }
    return _toUser(doc);
  }

  // -------------------------------------------------------------------- auth

  @override
  Future<AppUser> signUp({
    required String name,
    required String email,
    required String phone,
    required String ewallet,
    required String password,
  }) async {
    final cleanEmail = email.trim().toLowerCase();
    final data = await _auth('accounts:signUp', <String, dynamic>{
      'email': cleanEmail,
      'password': password,
      'returnSecureToken': true,
    });
    await _adopt(data);
    try {
      await _createProfile(
        uid: _requireUid(),
        name: name.trim(),
        phone: phone.trim(),
        ewallet: ewallet.trim(),
      );
    } on StoreException {
      await signOut();
      rethrow;
    }
    return _myProfile(emailHint: cleanEmail);
  }

  @override
  Future<AppUser> signIn({
    required String email,
    required String password,
  }) async {
    final cleanEmail = email.trim().toLowerCase();
    final data = await _auth('accounts:signInWithPassword', <String, dynamic>{
      'email': cleanEmail,
      'password': password,
      'returnSecureToken': true,
    });
    await _adopt(data);
    return _myProfile(emailHint: cleanEmail);
  }

  @override
  Future<AppUser?> restoreSession() async {
    if (!CloudConfig.isConfigured) return null;
    _session ??= await _file.read();
    if (_session == null) return null;
    try {
      return await _myProfile();
    } on StoreException catch (error) {
      final text = error.message.toLowerCase();
      final offline = text.contains('internet') || text.contains('too long');
      if (!offline) await signOut();
      return null;
    }
  }

  @override
  Future<void> signOut() async {
    _session = null;
    await _file.clear();
  }

  // ------------------------------------------------------------------- users

  @override
  Future<List<AppUser>> getUsers() async {
    final docs = await _query(
      'users',
      equals: <List<String>>[
        <String>['role', 'student'],
      ],
    );
    final users = docs.map(_toUser).toList();
    users.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return users;
  }

  @override
  Future<AppUser?> getUser(String id) async {
    final doc = await _getDoc('users', id);
    return doc == null ? null : _toUser(doc);
  }

  // ------------------------------------------------------------- weighings

  @override
  Future<TxRecord> submitWeighing(double kg) async {
    final uid = _requireUid();
    if (kg <= 0 || kg > 100) {
      throw StoreException('Weight must be between 0 and 100 kg.');
    }
    final id = _newId();
    final now = DateTime.now();
    final amount = kg * StoreRules.pricePerKg;
    await _commit(<Map<String, dynamic>>[
      _write(
        'transactions',
        id,
        fields: <String, dynamic>{
          'userId': _s(uid),
          'type': _s(TxType.deposit),
          'status': _s(TxStatus.pending),
          'kg': _d(kg),
          'amount': _d(amount),
          'note': _s('Waste weighing'),
          'createdAt': _t(now),
        },
        precondition: <String, dynamic>{'exists': false},
      ),
    ]);
    return TxRecord(
      id: id,
      userId: uid,
      type: TxType.deposit,
      status: TxStatus.pending,
      kg: kg,
      amount: amount,
      note: 'Waste weighing',
      createdAt: now,
    );
  }

  @override
  Future<List<TxRecord>> getPendingWeighings() async {
    final docs = await _query(
      'transactions',
      equals: <List<String>>[
        <String>['type', TxType.deposit],
        <String>['status', TxStatus.pending],
      ],
    );
    return _sortedTx(docs);
  }

  @override
  Future<void> reviewWeighing(String txId, bool approve) async {
    final tx = await _getDoc('transactions', txId);
    if (tx == null ||
        tx.str('type') != TxType.deposit ||
        tx.str('status') != TxStatus.pending) {
      throw StoreException('This weighing is no longer pending.');
    }
    final writes = <Map<String, dynamic>>[
      _write(
        'transactions',
        txId,
        fields: <String, dynamic>{
          'status': _s(approve ? TxStatus.approved : TxStatus.rejected),
          'reviewedAt': _t(DateTime.now()),
        },
        mask: <String>['status', 'reviewedAt'],
        precondition: <String, dynamic>{'updateTime': tx.updateTime},
      ),
    ];
    if (approve) {
      writes.add(
        _write(
          'users',
          tx.str('userId'),
          mask: <String>[],
          increments: <Map<String, dynamic>>[
            _increment('balance', tx.dbl('amount')),
            _increment('totalKg', tx.dbl('kg')),
          ],
          precondition: <String, dynamic>{'exists': true},
        ),
      );
    }
    await _commit(writes);
  }

  // ---------------------------------------------------------- transactions

  @override
  Future<List<TxRecord>> getTransactions({String? userId}) async {
    final docs = await _query(
      'transactions',
      equals: userId == null
          ? const <List<String>>[]
          : <List<String>>[
              <String>['userId', userId],
            ],
    );
    return _sortedTx(docs);
  }

  @override
  Future<TxRecord> withdraw(double? amount) async {
    final uid = _requireUid();
    final me = await _getDoc('users', uid);
    if (me == null) throw StoreException('Student not found.');
    final balance = me.dbl('balance');
    final value = amount ?? balance;
    if (value < StoreRules.minWithdraw) {
      throw StoreException('Minimum withdrawal is Rp 10.000.');
    }
    if (value > balance) throw StoreException('Insufficient balance.');

    final id = _newId();
    final now = DateTime.now();
    final note = 'Payout to ${me.str('ewallet')}';
    await _commit(<Map<String, dynamic>>[
      _write(
        'users',
        uid,
        fields: <String, dynamic>{'balance': _d(balance - value)},
        mask: <String>['balance'],
        precondition: <String, dynamic>{'updateTime': me.updateTime},
      ),
      _write(
        'transactions',
        id,
        fields: <String, dynamic>{
          'userId': _s(uid),
          'type': _s(TxType.withdraw),
          'status': _s(TxStatus.completed),
          'kg': _d(0),
          'amount': _d(value),
          'note': _s(note),
          'createdAt': _t(now),
        },
        precondition: <String, dynamic>{'exists': false},
      ),
    ]);
    return TxRecord(
      id: id,
      userId: uid,
      type: TxType.withdraw,
      status: TxStatus.completed,
      kg: 0,
      amount: value,
      note: note,
      createdAt: now,
    );
  }

  // ------------------------------------------------------------------ demo

  @override
  Future<void> seedDemoData() async {
    await _seedOne('demo_aulia', 'Aulia Rahma', '081234567801',
        'DANA 081234567801', 6.5);
    await _seedOne('demo_rizky', 'Rizky Pratama', '081234567802',
        'GoPay 081234567802', 4.0);
  }

  Future<void> _seedOne(
    String id,
    String name,
    String phone,
    String wallet,
    double kg,
  ) async {
    final now = DateTime.now();
    final existing = await _getDoc('users', id);
    final writes = <Map<String, dynamic>>[];
    if (existing == null) {
      writes.add(
        _write(
          'users',
          id,
          fields: <String, dynamic>{
            'name': _s(name),
            'phone': _s(phone),
            'ewallet': _s(wallet),
            'role': _s('student'),
            'balance': _d(0),
            'totalKg': _d(0),
            'createdAt': _t(now),
          },
          precondition: <String, dynamic>{'exists': false},
        ),
      );
    }
    writes.add(
      _write(
        'transactions',
        _newId(),
        fields: <String, dynamic>{
          'userId': _s(id),
          'type': _s(TxType.deposit),
          'status': _s(TxStatus.pending),
          'kg': _d(kg),
          'amount': _d(kg * StoreRules.pricePerKg),
          'note': _s('Waste weighing'),
          'createdAt': _t(now),
        },
        precondition: <String, dynamic>{'exists': false},
      ),
    );
    await _commit(writes);
  }

  // ---------------------------------------------------------------- tickets

  @override
  Future<Ticket> createTicket({
    required String userId,
    required double kg,
  }) async {
    final adminId = _requireUid();
    if (kg <= 0 || kg > 100) {
      throw StoreException('Weight must be between 0 and 100 kg.');
    }
    final code = _newCode();
    final now = DateTime.now();
    final expires = now.add(_ticketLife);
    final amount = kg * StoreRules.pricePerKg;
    await _commit(<Map<String, dynamic>>[
      _write(
        'tickets',
        code,
        fields: <String, dynamic>{
          'userId': _s(userId),
          'kg': _d(kg),
          'amount': _d(amount),
          'createdBy': _s(adminId),
          'createdAt': _t(now),
          'expiresAt': _t(expires),
        },
        precondition: <String, dynamic>{'exists': false},
      ),
    ]);
    return Ticket(
      code: code,
      userId: userId,
      kg: kg,
      amount: amount,
      expiresAt: expires,
    );
  }

  @override
  Future<TxRecord> claimTicket(String code) async {
    final uid = _requireUid();
    final clean = code.trim().toUpperCase();
    final ticket = await _getDoc('tickets', clean);
    if (ticket == null) {
      throw StoreException('Ticket not found. Check the code and try again.');
    }
    if (ticket.str('userId') != uid) {
      throw StoreException('This ticket belongs to another student.');
    }
    if (ticket.fields.containsKey('claimedAt')) {
      throw StoreException('This ticket was already used.');
    }
    if (ticket.time('expiresAt').isBefore(DateTime.now())) {
      throw StoreException('This ticket has expired. Ask the admin for a new one.');
    }

    final kg = ticket.dbl('kg');
    final amount = ticket.dbl('amount');
    final now = DateTime.now();
    final note = 'Weighing ticket $clean';
    await _commit(<Map<String, dynamic>>[
      _write(
        'tickets',
        clean,
        fields: <String, dynamic>{'claimedAt': _t(now)},
        mask: <String>['claimedAt'],
        precondition: <String, dynamic>{'updateTime': ticket.updateTime},
      ),
      _write(
        'users',
        uid,
        fields: <String, dynamic>{'lastClaim': _s(clean)},
        mask: <String>['lastClaim'],
        increments: <Map<String, dynamic>>[
          _increment('balance', amount),
          _increment('totalKg', kg),
        ],
        precondition: <String, dynamic>{'exists': true},
      ),
      _write(
        'transactions',
        'claim_$clean',
        fields: <String, dynamic>{
          'userId': _s(uid),
          'type': _s(TxType.deposit),
          'status': _s(TxStatus.approved),
          'kg': _d(kg),
          'amount': _d(amount),
          'note': _s(note),
          'createdAt': _t(now),
          'reviewedAt': _t(now),
        },
        precondition: <String, dynamic>{'exists': false},
      ),
    ]);
    return TxRecord(
      id: 'claim_$clean',
      userId: uid,
      type: TxType.deposit,
      status: TxStatus.approved,
      kg: kg,
      amount: amount,
      note: note,
      createdAt: now,
    );
  }
}
