import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import 'theme.dart';
import 'widgets/widgets.dart';

class AppUpdate {
  const AppUpdate({required this.build, required this.url, required this.notes});

  final int build;
  final String url;
  final String notes;
}

/// Looks for a newer release on GitHub and offers the APK download.
///
/// The GitHub workflow (.github/workflows/build.yml) publishes a release called
/// build-<run number> with trash_school.apk and trash_school_admin.apk, and
/// builds each app with BUILD_NUMBER=<run number>. An app that was not built by
/// the workflow (BUILD_NUMBER 0, e.g. `flutter run`) never asks for an update.
/// Android never installs an APK silently: the person taps Download, then
/// opens the downloaded file.
class UpdateChecker {
  UpdateChecker._();

  /// "owner/repository" of your PUBLIC GitHub repository. The workflow sets it
  /// automatically; edit the default only when you build by hand.
  static const String repo = String.fromEnvironment(
    'GITHUB_REPO',
    defaultValue: 'YOUR-USER/YOUR-REPO',
  );

  static const int currentBuild = int.fromEnvironment(
    'BUILD_NUMBER',
    defaultValue: 0,
  );

  static Future<AppUpdate?> check({required String apkName}) async {
    if (repo.startsWith('YOUR-') || currentBuild <= 0) return null;
    try {
      final res = await http
          .get(
            Uri.parse('https://api.github.com/repos/$repo/releases/latest'),
            headers: const <String, String>{
              'Accept': 'application/vnd.github+json',
            },
          )
          .timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return null;
      final json = jsonDecode(utf8.decode(res.bodyBytes));
      if (json is! Map) return null;

      final tag = (json['tag_name'] as String?) ?? '';
      final match = RegExp(r'(\d+)$').firstMatch(tag);
      final build = match == null ? 0 : int.tryParse(match.group(1)!) ?? 0;
      if (build <= currentBuild) return null;

      String? url;
      final assets = json['assets'];
      if (assets is List) {
        for (final asset in assets) {
          if (asset is Map &&
              asset['name'] == apkName &&
              asset['browser_download_url'] is String) {
            url = asset['browser_download_url'] as String;
          }
        }
      }
      url ??= json['html_url'] as String?;
      if (url == null) return null;

      return AppUpdate(
        build: build,
        url: url,
        notes: ((json['body'] as String?) ?? '').trim(),
      );
    } catch (_) {
      // No internet, rate limit, private repo...: just skip the update check.
      return null;
    }
  }

  /// Shows an "Update available" dialog when a newer build exists.
  static Future<void> promptIfAvailable(
    BuildContext context, {
    required String apkName,
  }) async {
    final update = await check(apkName: apkName);
    if (update == null || !context.mounted) return;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Update available'),
        content: Text(
          update.notes.isEmpty
              ? 'A newer version (build ${update.build}) is ready. '
                  'Download it, then open the file to install.'
              : 'Build ${update.build} is ready.\n\n${update.notes}',
          style: const TextStyle(color: AppColors.textMuted),
        ),
        actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        actions: [
          AnimatedButton(
            label: 'Later',
            style: AppButtonStyle.outlined,
            expand: false,
            dense: true,
            onPressed: () => Navigator.of(dialogContext).pop(),
          ),
          AnimatedButton(
            label: 'Download',
            icon: Icons.download,
            expand: false,
            dense: true,
            onPressed: () async {
              Navigator.of(dialogContext).pop();
              try {
                await launchUrl(
                  Uri.parse(update.url),
                  mode: LaunchMode.externalApplication,
                );
              } catch (_) {
                // Nothing to do: the person can still update from GitHub.
              }
            },
          ),
        ],
      ),
    );
  }
}
