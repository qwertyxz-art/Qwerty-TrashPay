import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import 'shared_store.dart';
import 'theme.dart';
import 'widgets/widgets.dart';

/// Scans the weighing QR the admin shows (or takes the typed code) and turns it
/// into balance. Pops the new [TxRecord] when it worked.
class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final MobileScannerController _controller = MobileScannerController(
    formats: const <BarcodeFormat>[BarcodeFormat.qrCode],
    detectionSpeed: DetectionSpeed.noDuplicates,
  );
  final TextEditingController _manual = TextEditingController();

  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _manual.dispose();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _redeem(String raw) async {
    if (_busy) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final tx = await SharedStore.claimTicket(raw);
      if (!mounted) return;
      Navigator.of(context).pop(tx);
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = '$error';
      });
      await _scanAgain();
    }
  }

  /// After a failed scan the camera must restart, otherwise the same QR code
  /// would not be detected a second time.
  Future<void> _scanAgain() async {
    try {
      await _controller.stop();
      await _controller.start();
    } catch (_) {
      // The camera may be unavailable: the typed code still works.
    }
  }

  void _onDetect(BarcodeCapture capture) {
    if (_busy) return;
    for (final barcode in capture.barcodes) {
      final raw = barcode.rawValue;
      if (raw != null && raw.isNotEmpty) {
        _redeem(raw);
        return;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan weighing QR')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'Point the camera at the QR code the admin shows after '
              'weighing your waste. You need an internet connection.',
              style: TextStyle(color: AppColors.textMuted),
            ),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: SizedBox(
                height: 300,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    MobileScanner(controller: _controller, onDetect: _onDetect),
                    IgnorePointer(
                      child: Center(
                        child: Container(
                          width: 200,
                          height: 200,
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColors.accent, width: 3),
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      ),
                    ),
                    if (_busy)
                      Container(
                        color: Colors.black54,
                        child: const Center(child: CircularProgressIndicator()),
                      ),
                  ],
                ),
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 14),
              AppCard(
                child: Row(
                  children: [
                    const Icon(Icons.error_outline, color: AppColors.danger),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _error!,
                        style: const TextStyle(color: AppColors.danger),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 24),
            const Text(
              'No camera, or it will not scan?',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 4),
            const Text(
              'Type the code printed under the QR.',
              style: TextStyle(color: AppColors.textMuted),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _manual,
              textCapitalization: TextCapitalization.characters,
              autocorrect: false,
              enableSuggestions: false,
              textInputAction: TextInputAction.done,
              onSubmitted: _redeem,
              decoration: appInputDecoration(
                label: 'Ticket code',
                hint: 'e.g. 7K2M9QX4PA',
                icon: Icons.confirmation_number_outlined,
              ),
            ),
            const SizedBox(height: 12),
            AnimatedButton(
              label: 'Redeem code',
              icon: Icons.check_circle_outline,
              loading: _busy,
              onPressed: () => _redeem(_manual.text),
            ),
          ],
        ),
      ),
    );
  }
}
