import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'cloud_config.dart';
import 'models.dart';

/// What a cloud backend must be able to do. SupabaseBackend and
/// FirebaseBackend both implement it, so the screens never know which one runs.
abstract class CloudBackend {
  Future<AppUser> signUp({
    required String name,
    required String email,
    required String phone,
    required String ewallet,
    required String password,
  });

  Future<AppUser> signIn({required String email, required String password});

  Future<AppUser?> restoreSession();

  Future<void> signOut();

  Future<List<AppUser>> getUsers();

  Future<AppUser?> getUser(String id);

  Future<TxRecord> submitWeighing(double kg);

  Future<List<TxRecord>> getPendingWeighings();

  Future<void> reviewWeighing(String txId, bool approve);

  Future<List<TxRecord>> getTransactions({String? userId});

  Future<TxRecord> withdraw(double? amount);

  Future<void> seedDemoData();

  /// Admin: creates a one-time ticket for [userId] after weighing [kg].
  Future<Ticket> createTicket({required String userId, required double kg});

  /// Student: turns a ticket into balance (needs the internet).
  Future<TxRecord> claimTicket(String code);
}

/// Login tokens of the signed-in user.
class AuthSession {
  AuthSession({
    required this.accessToken,
    required this.refreshToken,
    required this.userId,
  });

  String accessToken;
  String refreshToken;
  final String userId;
}

/// Remembers the login on the phone (a small JSON file in the documents
/// directory). Nothing else is stored locally.
class SessionFile {
  SessionFile(this.fileName);

  final String fileName;

  Future<File> _file() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$fileName');
  }

  Future<AuthSession?> read() async {
    try {
      final file = await _file();
      if (!await file.exists()) return null;
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! Map) return null;
      final access = decoded['accessToken'];
      final refresh = decoded['refreshToken'];
      final userId = decoded['userId'];
      if (access is String && refresh is String && userId is String) {
        return AuthSession(
          accessToken: access,
          refreshToken: refresh,
          userId: userId,
        );
      }
    } catch (_) {
      // Corrupted file: treat as signed out.
    }
    return null;
  }

  Future<void> write(AuthSession session) async {
    try {
      final file = await _file();
      await file.writeAsString(
        jsonEncode(<String, dynamic>{
          'accessToken': session.accessToken,
          'refreshToken': session.refreshToken,
          'userId': session.userId,
        }),
        flush: true,
      );
    } catch (_) {
      // Not being able to remember the login is not fatal.
    }
  }

  Future<void> clear() async {
    try {
      final file = await _file();
      if (await file.exists()) await file.delete();
    } catch (_) {
      // Ignore.
    }
  }
}

void ensureCloudConfigured() {
  if (!CloudConfig.isConfigured) {
    throw StoreException(
      'The cloud is not set up yet. Fill in lib/cloud_config.dart '
      '(see README).',
    );
  }
}
