# TrashPay Schools (student app)

Register or sign in, scan the QR ticket the admin shows after weighing (or type its code), see History, and Withdraw (simulated payout). "Simulate QR Scan" is a demo button controlled by `demoMode`.

Data lives in Supabase or Firebase. Setup steps are in the README at the root of the zip; set the backend and its keys in `lib/cloud_config.dart`.

```
# from the repository root, once (creates android/ with your Flutter's template)
python3 tools/setup_android.py trash_school

cd trash_school
flutter pub get
flutter run
flutter build apk --release --no-shrink
```
