# TrashPay Schools

Two Flutter apps that share one cloud database. You can run them on **Supabase** or on **Firebase**; pick one in `lib/cloud_config.dart`:

```dart
static const String backend = String.fromEnvironment('BACKEND', defaultValue: 'supabase'); // or 'firebase'
```

- `trash_school/`: student app (register, sign in, scan, history, withdraw)
- `trash_school_admin/`: admin app (dashboard, approvals, students, full history)

A weighing a student submits shows up in the admin app on any phone, and the admin's approval shows up in the student app. Set the same backend and the same keys in BOTH apps.

Both backends use only the `http` package (no Firebase or Supabase plugin, no `google-services.json`). The only native plugins are `mobile_scanner` (camera, student app) and `url_launcher` (opens the update download).

## Option A: Supabase

1. Create a free project at https://supabase.com.
2. SQL Editor > New query: paste all of `supabase_setup.sql` and Run.
3. Authentication > Sign In / Providers > Email: turn **Confirm email** OFF.
4. Authentication > Users > Add user > Create new user: email `principal@trashpay.school`, a **strong password of your own** (not an easy one: anyone who has the APK can try to sign in), tick **Auto Confirm User**.
5. SQL Editor: `update public.profiles set role = 'admin' where phone = 'principal';`
6. Project Settings > API: copy the **Project URL** and the **anon public** key into `lib/cloud_config.dart` (`url`, `anonKey`) of both apps, or into GitHub repository variables (see the GitHub section). Never use the `service_role` key in an app.

## Option B: Firebase

1. Create a project at https://console.firebase.google.com.
2. Build > Authentication > Get started > Sign-in method: enable **Email/Password**.
3. Build > Firestore Database > Create database (production mode, any region).
4. Firestore > Rules: paste all of `firestore.rules` and Publish.
5. Authentication > Users > Add user: email `principal@trashpay.school` and a **strong password of your own**. Copy that user's **User UID**.
6. Firestore > Start collection `users` > Document ID = that UID, with these fields:
   `name` (string) Principal, `phone` (string) principal, `ewallet` (string) empty, `role` (string) **admin**, `balance` (number) 0, `totalKg` (number) 0, `createdAt` (timestamp) now.
7. Project settings > General: copy the **Project ID** and **Web API Key** into `lib/cloud_config.dart` (`firebaseProjectId`, `firebaseApiKey`) of both apps, and change the default of `backend` to `'firebase'`.

Admin login in the app (both options): username `principal` and the password you chose above.

You can also set everything at build time instead of editing the file, for example:
`flutter build apk --release --dart-define=BACKEND=firebase --dart-define=FIREBASE_PROJECT_ID=... --dart-define=FIREBASE_API_KEY=...`

## Build

The `android/` folders are not stored in this repository: they are generated with the Flutter version you have installed, so Gradle and Kotlin always match it. GitHub does this for you (see below). By hand, from the repository root:

```
python3 tools/setup_android.py trash_school
cd trash_school && flutter pub get && flutter build apk --release --no-shrink
cd ..
python3 tools/setup_android.py trash_school_admin
cd trash_school_admin && flutter pub get && flutter build apk --release --no-shrink
```

## How it works

- Students register with name, email, phone, e-wallet and a password. Sign in is email + password and stays remembered on the phone.
- **Weighing with a QR ticket (the real flow):**
  1. The admin weighs the waste on the physical scale, opens **New weighing (QR ticket)** on the dashboard, picks the student and types the weight.
  2. The server creates a one-time ticket and the admin app shows it as a QR code with a short code underneath.
  3. The student taps **Scan Weighing QR**, points the camera at it (or types the code), and the balance is credited at Rp 2.500 per kg.
- The ticket only works **online** (no signal = error), **once**, **for that student only**, and for **10 minutes**. No weighing means no ticket, so there is nothing to scan.
- The app cannot sense weight by itself: the number comes from the scale, typed by the admin.
- The old "Simulate QR Scan" button (adds a pending 5.0 kg for the admin to approve in the Pending tab) stays for demos while `demoMode` is true in `lib/cloud_config.dart`. Set it to false for real use.
- Withdraw (simulated payout, minimum Rp 10.000) is recorded in the history.
- The admin app's History tab lists every weighing and payout from all students. Use the refresh button to pull new data.
- "Seed Demo Data" (admin app) adds 2 demo students and 2 pending weighings in the cloud.
- Balances are protected on the server (database functions in `supabase_setup.sql`, or `firestore.rules`), so a student cannot give themselves money.
- Only the login session is stored on the phone (`path_provider` JSON file).
- The student app uses the camera through the `mobile_scanner` plugin. The permission is declared in its manifest and the manual code field works without it.

## GitHub: build the APKs and download them

`.github/workflows/build.yml` builds both apps on GitHub and publishes them as a Release (`build-<number>`, with `trash_school.apk` and `trash_school_admin.apk`).

1. Create a **public** repository on GitHub and upload everything in this zip so that this README sits at the top of the repository. Include the hidden `.github` folder.
2. Tell the apps where your cloud is. Either edit `lib/cloud_config.dart` in both apps before uploading, or add repository variables (Settings > Secrets and variables > Actions > **Variables** > New repository variable): `SUPABASE_URL` and `SUPABASE_ANON_KEY` (Firebase: `BACKEND` = `firebase`, `FIREBASE_PROJECT_ID`, `FIREBASE_API_KEY`). Optional: `DEMO_MODE` = `false` hides the demo button. These keys are public by design; use the anon key only.
3. Actions tab > Build and release APKs > Run workflow (it also runs on every push to `main`). Wait for the two builds to turn green, a few minutes.
4. On the phone: repository > Releases > the newest build > download `trash_school.apk` (students) or `trash_school_admin.apk` (admin) and install it. Allow "install unknown apps" for the browser when Android asks.

What the workflow takes care of:

- It generates the Android project with the newest stable Flutter, adds the INTERNET and camera permissions, and builds without code shrinking.
- It stops with a red check instead of publishing an APK that is unsigned or has no 64-bit Flutter engine.
- The signing key is created on the first run and kept in the Actions cache, so a new build installs over the old one. If the cache is lost (not used for 7 days), the key changes: uninstall the old app once, then install the new one.
- Each app checks GitHub for a newer build when it opens and shows **Update available** with a Download button. Android never installs silently: tap Download, then open the file. A private repository hides its releases from the apps.

## Troubleshooting

- "The cloud is not set up yet": the keys in `cloud_config.dart` are still placeholders, or `backend` points to the other option.
- Supabase: "still wants email confirmation" means step 3 was skipped; "profile was not found" means `supabase_setup.sql` was not run completely.
- Firebase: "Not allowed by the Firestore rules" means the rules were not published; "Email/password sign-in is turned off" means step 2 was skipped.
- Scan says "No internet connection": the ticket can only be redeemed online, by design.
- "This ticket belongs to another student", "already used", "expired": ask the admin to create a new ticket for that student.
- "This account is not an admin account": the admin step (Supabase step 5 or Firebase step 6) was skipped.
- App closes right after the splash screen: that is a native crash, not a Dart error. Note the phone model and Android version. With a computer: enable USB debugging, install the APK, open the app and run `adb logcat -d -b crash` (or `adb logcat -d | grep -i -E "flutter|AndroidRuntime|FATAL"`); the first red lines name the cause.
- The workflow is red at "Generate the Android project" or "Check the APK": open that step in the Actions log; the message says what is missing.
